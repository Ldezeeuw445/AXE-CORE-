/**
 * chatPersistence.ts
 * ------------------------------------------------------------------
 * Persists AXE CORE chat exchanges to the Supabase `messages` table.
 * ISOLATED per app — AXE Core, AXE Companion, and Trading OS each
 * have their own siloed conversation history via `app_source`.
 */

import { getSupabase } from '@/lib/supabaseClient';
import { isAxeApiConfigured, sbGetRows, sbInsertRow } from '@/services/axeCoreApiService';

export type ChatRole = 'user' | 'axe' | 'system';

/** App identifier — CHANGE PER APP:
 *  - AXE Core:       'axe-core'
 *  - AXE Companion:  'axe-companion'
 *  - Trading OS:     'trading-os'
 */
export const APP_SOURCE = 'axe-core';

/** Per-app user ID so each app has its own conversation namespace */
export const AXE_USER_ID = `acff7a12-1111-481d-a7a9-cc07583b8069-${APP_SOURCE}`;

export interface ChatMessageRecord {
  id?: string;
  conversation_id: string;
  user_id?: string;
  role: ChatRole;
  content: string;
  provider?: string | null;
  model?: string | null;
  metadata?: Record<string, unknown>;
  created_at?: string;
}

export interface ConversationMessage {
  role: ChatRole;
  text: string;
  timestamp: number;
  provider?: string;
  model?: string;
}

export interface ConversationSummary {
  id: string;
  title: string;
  messageCount: number;
  lastMessageAt: string;
  preview: string;
}

/** Extract app_source from metadata object */
function getAppSource(meta: unknown): string | null {
  if (meta && typeof meta === 'object' && 'app_source' in (meta as Record<string, unknown>)) {
    return String((meta as Record<string, unknown>).app_source);
  }
  return null;
}

/** Check if a message belongs to this app */
function isOurApp(row: ChatMessageRecord): boolean {
  // Strict: must match our app_source OR our user_id
  const rowApp = getAppSource(row.metadata);
  if (rowApp !== null) return rowApp === APP_SOURCE;
  // Fallback: check user_id contains our app suffix
  if (row.user_id && row.user_id.includes(APP_SOURCE)) return true;
  // Reject messages without app_source and without matching user_id
  // (these are from other apps stored before isolation)
  return false;
}

/** Build metadata with app_source */
function buildMeta(extra?: Record<string, unknown>): Record<string, unknown> {
  return { app_source: APP_SOURCE, ...(extra || {}) };
}

/** chatPersistence.ts fallback helpers */
const LS_FALLBACK_PREFIX = 'axe_fallback_msgs_';

function fallbackSave(msg: ChatMessageRecord): void {
  try {
    const key = `${LS_FALLBACK_PREFIX}${msg.conversation_id}`;
    const existing: Array<{ role: string; content: string; timestamp: number; provider?: string | null; model?: string | null }> = JSON.parse(localStorage.getItem(key) || '[]');
    existing.push({
      role: msg.role,
      content: msg.content,
      timestamp: Date.now(),
      provider: msg.provider,
      model: msg.model,
    });
    localStorage.setItem(key, JSON.stringify(existing.slice(-300)));
  } catch {}
}

function fallbackLoad(conversationId: string): ConversationMessage[] {
  try {
    const key = `${LS_FALLBACK_PREFIX}${conversationId}`;
    const raw = localStorage.getItem(key);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return parsed.map((m: Record<string, unknown>) => ({
      role: (m.role === 'user' ? 'user' : 'axe') as 'user' | 'axe',
      text: String(m.content || ''),
      timestamp: Number(m.timestamp || Date.now()),
      provider: m.provider ? String(m.provider) : undefined,
      model: m.model ? String(m.model) : undefined,
    }));
  } catch { return []; }
}

function fallbackAllConversations(): ConversationSummary[] {
  try {
    const keys = Object.keys(localStorage).filter(k => k.startsWith(LS_FALLBACK_PREFIX));
    return keys.map(k => {
      const msgs: Array<{ content?: string; timestamp?: number }> = JSON.parse(localStorage.getItem(k) || '[]');
      const lastMsg = msgs[msgs.length - 1];
      const cid = k.replace(LS_FALLBACK_PREFIX, '');
      return {
        id: cid,
        title: (lastMsg?.content || '').slice(0, 20) || cid.slice(0, 8),
        messageCount: msgs.length,
        lastMessageAt: lastMsg?.timestamp ? new Date(lastMsg.timestamp).toISOString() : new Date().toISOString(),
        preview: (lastMsg?.content || '').slice(0, 60),
      };
    }).sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt));
  } catch { return []; }
}


export async function loadMessages(conversationId: string): Promise<ConversationMessage[]> {
  try {
    let rows: ChatMessageRecord[] = [];

    if (isAxeApiConfigured) {
      rows = (await sbGetRows('messages', {
        limit: 500,
        orderBy: 'created_at',
        orderDir: 'asc',
        filterCol: 'conversation_id',
        filterVal: conversationId,
      })) as unknown as ChatMessageRecord[];
    } else {
      const sb = getSupabase();
      if (!sb) return [];
      const { data, error } = await sb
        .from('messages')
        .select('*')
        .eq('conversation_id', conversationId)
        .eq('user_id', AXE_USER_ID)
        .order('created_at', { ascending: true })
        .limit(500);
      if (error) { console.error('[chatPersistence] loadMessages error:', error); return []; }
      rows = data || [];
    }

    // 🔒 FILTER: only show messages belonging to THIS app
    return rows
      .filter(isOurApp)
      .map((r) => ({
        role: (r.role === 'user' ? 'user' : 'axe') as 'user' | 'axe',
        text: r.content ?? '',
        timestamp: r.created_at ? Date.parse(r.created_at) : Date.now(),
        provider: r.provider ?? undefined,
        model: r.model ?? undefined,
      }));
  } catch (err) {
    console.error('[chatPersistence] loadMessages failed:', err);
    return fallbackLoad(conversationId);
  }
}

/** Save a single message to the `messages` table. */
export async function saveMessage(msg: ChatMessageRecord): Promise<void> {
  const record = {
    conversation_id: msg.conversation_id,
    user_id: msg.user_id ?? AXE_USER_ID,
    role: msg.role,
    content: msg.content,
    provider: msg.provider ?? null,
    model: msg.model ?? null,
    metadata: buildMeta(msg.metadata),
  };

  try {
    if (isAxeApiConfigured) {
      await sbInsertRow('messages', record as Record<string, unknown>);
      return;
    }

    const sb = getSupabase();
    if (!sb) return;
    const { error } = await sb.from('messages').insert(record);
    if (error) console.error('[chatPersistence] saveMessage error:', error);
  } catch (err) {
    console.error('[chatPersistence] saveMessage failed:', err);
    fallbackSave(msg);
  }
}

/** Groups messages by conversation_id and returns metadata for each.
 *  🔒 FILTERED per app_source so AXE Core only sees AXE Core chats. */
export async function loadAllConversations(): Promise<ConversationSummary[]> {
  try {
    let rows: ChatMessageRecord[] = [];

    if (isAxeApiConfigured) {
      rows = (await sbGetRows('messages', {
        limit: 1000,
        orderBy: 'created_at',
        orderDir: 'desc',
        filterCol: 'user_id',
        filterVal: AXE_USER_ID,
      })) as unknown as ChatMessageRecord[];
    } else {
      const sb = getSupabase();
      if (!sb) return [];

      // Load ALL messages for this user_id prefix, then filter by app
      const { data, error } = await sb
        .from('messages')
        .select('conversation_id, content, created_at, metadata, user_id, role')
        .order('created_at', { ascending: false })
        .limit(1000);
      if (error) { console.error('[chatPersistence] loadAllConv error:', error); return []; }
      rows = (data ?? []) as unknown as ChatMessageRecord[];
    }

    // 🔒 FILTER: only conversations belonging to THIS app
    const ourRows = rows.filter(isOurApp);

    // Group by conversation_id
    const convMap = new Map<string, { messages: number; lastAt: string; preview: string }>();
    for (const row of ourRows) {
      const cid = row.conversation_id;
      const existing = convMap.get(cid);
      if (!existing) {
        convMap.set(cid, {
          messages: 1,
          lastAt: row.created_at ?? new Date().toISOString(),
          preview: (row.content ?? '').slice(0, 60),
        });
      } else {
        existing.messages++;
        if ((row.created_at ?? '') > existing.lastAt) {
          existing.lastAt = row.created_at ?? existing.lastAt;
          if (!existing.preview) existing.preview = (row.content ?? '').slice(0, 60);
        }
      }
    }

    return Array.from(convMap.entries())
      .map(([id, meta]) => ({
        id,
        title: meta.preview.slice(0, 20) || id.slice(0, 8),
        messageCount: meta.messages,
        lastMessageAt: meta.lastAt,
        preview: meta.preview,
      }))
      .sort((a, b) => b.lastMessageAt.localeCompare(a.lastMessageAt));
  } catch (err) {
    console.error('[chatPersistence] loadAllConversations failed:', err);
    return fallbackAllConversations();
  }
}

/**
 * Generate a new conversation ID.
 * Must be a real UUID — the `messages.conversation_id` column is typed
 * `uuid` in Supabase, so a custom string id (e.g. "axe-core-<ts>-<rand>")
 * fails every insert/select with "invalid input syntax for type uuid".
 * Per-app isolation is handled separately via `app_source` in metadata
 * and the per-app `user_id`, so the id itself doesn't need an app prefix.
 */
export function createNewConversationId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  // Fallback UUID v4 generator for environments without crypto.randomUUID
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}
