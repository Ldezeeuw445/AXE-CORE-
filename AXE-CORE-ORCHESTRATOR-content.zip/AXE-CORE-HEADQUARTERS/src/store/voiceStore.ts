import { create } from 'zustand';

export type VoiceStatus = 'idle' | 'listening' | 'processing' | 'speaking';

interface ConversationMessage {
  role: 'user' | 'axe';
  text: string;
  timestamp: number;
}

interface VoiceState {
  apiKey: string;
  apiKeyValid: boolean | null;
  voiceStatus: VoiceStatus;
  transcript: string;
  response: string;
  conversation: ConversationMessage[];
  error: string | null;
  recognitionSupported: boolean;
  micPermission: 'granted' | 'denied' | 'prompt' | 'unknown';

  setApiKey: (key: string) => void;
  testApiKey: () => Promise<boolean>;
  clearError: () => void;
  setError: (error: string | null) => void;
  clearConversation: () => void;
  checkMicPermission: () => Promise<void>;

  startListening: () => Promise<void>;
  stopListening: () => void;
  sendMessage: (text: string) => Promise<void>;
}

/* ── Safe localStorage ── */
function getStoredKey(): string {
  try { return localStorage.getItem('axe_api_key') || ''; } catch { return ''; }
}
function setStoredKey(key: string) {
  try { localStorage.setItem('axe_api_key', key); } catch { /* ignore */ }
}

/* ── Safe TTS ── */
function speakSafely(text: string, onDone?: () => void) {
  try {
    if (!('speechSynthesis' in window)) { onDone?.(); return; }
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'nl-NL';
    u.rate = 1.1;
    u.pitch = 0.85;
    u.volume = 1.0;
    // Defer voice selection to avoid empty voices array
    setTimeout(() => {
      try {
        const voices = window.speechSynthesis.getVoices();
        const v = voices.find((v) => v.lang.startsWith('nl') || v.lang.startsWith('en'));
        if (v) u.voice = v;
      } catch { /* ignore */ }
    }, 0);
    u.onend = () => onDone?.();
    u.onerror = () => onDone?.();
    window.speechSynthesis.speak(u);
  } catch {
    onDone?.();
  }
}

/* ── Speech Recognition ── */
const SpeechRecCtor = typeof window !== 'undefined'
  ? (window.SpeechRecognition || window.webkitSpeechRecognition) : null;

let recInstance: SpeechRecognition | null = null;
function getRec(): SpeechRecognition | null {
  if (!SpeechRecCtor) return null;
  if (!recInstance) {
    recInstance = new SpeechRecCtor();
    recInstance.continuous = false;
    recInstance.interimResults = true;
    recInstance.lang = 'nl-NL';
  }
  return recInstance;
}

/* ── Store ── */
export const useVoiceStore = create<VoiceState>((set, get) => ({
  apiKey: getStoredKey(),
  apiKeyValid: null,
  voiceStatus: 'idle',
  transcript: '',
  response: '',
  conversation: [],
  error: null,
  recognitionSupported: !!SpeechRecCtor,
  micPermission: 'unknown',

  setApiKey: (key: string) => {
    setStoredKey(key);
    set({ apiKey: key, apiKeyValid: null, error: null });
  },

  testApiKey: async () => {
    const key = get().apiKey;
    if (!key) { set({ error: 'No API key set.' }); return false; }
    set({ voiceStatus: 'processing', error: null });
    try {
      const res = await fetch('https://api.moonshot.cn/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'moonshot-v1-8k', messages: [{ role: 'user', content: 'Hi' }], max_tokens: 5 }),
      });
      if (res.ok) { set({ apiKeyValid: true, voiceStatus: 'idle', error: null }); return true; }
      const err = await res.json().catch(() => ({}));
      set({ apiKeyValid: false, voiceStatus: 'idle', error: `API Error ${res.status}: ${err.error?.message || res.statusText}` });
      return false;
    } catch (e: unknown) {
      const m = e instanceof Error ? e.message : String(e);
      set({ apiKeyValid: false, voiceStatus: 'idle', error: m.includes('CORS') || m.includes('Failed to fetch') ? 'CORS blocked. Install "CORS Unblock" extension or use a proxy.' : `Network: ${m}` });
      return false;
    }
  },

  clearError: () => set({ error: null }),
  setError: (error: string | null) => set({ error }),
  clearConversation: () => set({ conversation: [], transcript: '', response: '' }),

  checkMicPermission: async () => {
    try {
      if ('permissions' in navigator) {
        const r = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        set({ micPermission: r.state as 'granted' | 'denied' | 'prompt' });
      }
    } catch { /* ignore */ }
  },

  startListening: async () => {
    try {
      const rec = getRec();
      if (!rec) { set({ error: 'Speech recognition not supported.' }); return; }

      await get().checkMicPermission();
      if (get().micPermission === 'denied') {
        set({ error: 'Microphone blocked. Click lock icon → Site Settings → Microphone → Allow → Refresh.' });
        return;
      }

      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        stream.getTracks().forEach((t) => t.stop());
        set({ micPermission: 'granted' });
      } catch {
        set({ error: 'Microphone permission denied.' });
        return;
      }

      try { window.speechSynthesis.cancel(); } catch { /* ignore */ }
      set({ transcript: '', response: '', voiceStatus: 'listening', error: null });

      rec.onresult = (event: SpeechRecognitionEvent) => {
        let final = '';
        for (let i = 0; i < event.results.length; i++) {
          if (event.results[i].isFinal) final += event.results[i][0].transcript;
        }
        set({ transcript: final || get().transcript });
        if (final) {
          set({ voiceStatus: 'processing' });
          get().sendMessage(final).catch(() => set({ voiceStatus: 'idle' }));
        }
      };

      rec.onerror = (event: SpeechRecognitionErrorEvent) => {
        if (event.error === 'not-allowed') set({ voiceStatus: 'idle', micPermission: 'denied', error: 'Microphone blocked. Allow in browser settings.' });
        else if (event.error !== 'no-speech') set({ voiceStatus: 'idle', error: `Speech error: ${event.error}` });
        else set({ voiceStatus: 'idle' });
      };

      rec.onend = () => { if (get().voiceStatus === 'listening') set({ voiceStatus: 'idle' }); };
      rec.start();
    } catch (e: unknown) {
      const m = e instanceof Error ? e.message : String(e);
      set({ voiceStatus: 'idle', error: `Voice error: ${m}` });
    }
  },

  stopListening: () => {
    try {
      const rec = getRec();
      if (rec) { try { rec.stop(); } catch { /* ignore */ } }
      try { window.speechSynthesis.cancel(); } catch { /* ignore */ }
    } catch { /* ignore */ }
    set({ voiceStatus: 'idle' });
  },

  sendMessage: async (text: string) => {
    if (!text?.trim()) return;
    const key = get().apiKey;
    if (!key) { set({ error: 'No API key. Go to Settings > AI Configuration.', voiceStatus: 'idle' }); return; }

    // Add user message
    set((s) => ({ conversation: [...s.conversation, { role: 'user' as const, text, timestamp: Date.now() }].slice(-50) }));
    set({ voiceStatus: 'processing', error: null });

    try {
      const history = get().conversation.slice(-12).map((m) => ({
        role: m.role === 'user' ? 'user' as const : 'assistant' as const,
        content: m.text,
      }));

      const res = await fetch('https://api.moonshot.cn/v1/chat/completions', {
        method: 'POST',
        headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'moonshot-v1-8k',
          messages: [
            { role: 'system', content: 'You are AXE, the AI assistant for the AXE Command Center. Speak like JARVIS from Iron Man. Keep responses to 1-2 short sentences. Match the user language (Dutch or English).' },
            ...history,
          ],
          temperature: 0.7,
          max_tokens: 150,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error?.message || `HTTP ${res.status}`);
      }

      const data = await res.json();
      const reply = data.choices?.[0]?.message?.content?.trim() || 'I could not process that.';

      set((s) => ({ conversation: [...s.conversation, { role: 'axe' as const, text: reply, timestamp: Date.now() }].slice(-50) }));
      set({ response: reply, voiceStatus: 'speaking', apiKeyValid: true });
      speakSafely(reply, () => set({ voiceStatus: 'idle' }));
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      let friendly = msg;
      if (msg.includes('CORS') || msg.includes('Failed to fetch')) friendly = 'CORS blocked. Use "CORS Unblock" extension, or a proxy like corsproxy.io';
      else if (msg.includes('401') || msg.includes('Unauthorized')) friendly = 'Invalid API key. Check your key in Settings.';
      else if (msg.includes('429')) friendly = 'Rate limit reached. Wait a moment.';
      set({ error: friendly, voiceStatus: 'idle', apiKeyValid: false });
    }
  },
}));
