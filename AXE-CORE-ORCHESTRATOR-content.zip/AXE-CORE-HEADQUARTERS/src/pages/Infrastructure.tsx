import { useEffect, useRef, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import * as d3 from 'd3';
import {
  ZoomIn,
  ZoomOut,
  Maximize2,
  RotateCcw,
  Database,
  Cloud,
  Triangle,
  TrainFront,
  Mail,
  Code2,
  TrendingUp,
  Search,
  Eye,
  Globe,
  Cpu,
  Bot,
  BrainCircuit,
} from 'lucide-react';

/* ------------------------------------------------------------------ */
/*  DATA                                                               */
/* ------------------------------------------------------------------ */

interface InfraNode {
  id: string;
  name: string;
  type: 'core' | 'service' | 'agent';
  status: 'online' | 'idle' | 'active';
  color: string;
  glowColor: string;
  icon: string;
  radius: number;
  connections: number;
}

interface InfraLink {
  source: string;
  target: string;
  type: 'core' | 'service' | 'agent';
}

const nodes: InfraNode[] = [
  /* Core */
  { id: 'axe-core', name: 'AXE Core', type: 'core', status: 'online', color: '#22D3EE', glowColor: 'rgba(34,211,238,0.4)', icon: 'cpu', radius: 32, connections: 9 },
  { id: 'axe-companion', name: 'AXE Companion', type: 'core', status: 'active', color: '#10B981', glowColor: 'rgba(16,185,129,0.4)', icon: 'bot', radius: 26, connections: 4 },
  { id: 'axe-intel', name: 'AXE Intel', type: 'core', status: 'online', color: '#3B82F6', glowColor: 'rgba(59,130,246,0.4)', icon: 'brain', radius: 26, connections: 5 },
  /* Services */
  { id: 'supabase', name: 'Supabase', type: 'service', status: 'online', color: '#3ECF8E', glowColor: 'rgba(62,207,142,0.3)', icon: 'database', radius: 22, connections: 2 },
  { id: 'cloudflare', name: 'Cloudflare', type: 'service', status: 'online', color: '#F48120', glowColor: 'rgba(244,129,32,0.3)', icon: 'cloud', radius: 22, connections: 3 },
  { id: 'vercel', name: 'Vercel', type: 'service', status: 'online', color: '#FFFFFF', glowColor: 'rgba(255,255,255,0.2)', icon: 'triangle', radius: 22, connections: 2 },
  { id: 'railway', name: 'Railway', type: 'service', status: 'idle', color: '#A855F7', glowColor: 'rgba(168,85,247,0.3)', icon: 'train', radius: 22, connections: 1 },
  { id: 'resend', name: 'Resend', type: 'service', status: 'online', color: '#E5E7EB', glowColor: 'rgba(229,231,235,0.2)', icon: 'mail', radius: 22, connections: 1 },
  /* Agents */
  { id: 'coding-agent', name: 'Coding Agent', type: 'agent', status: 'active', color: '#22D3EE', glowColor: 'rgba(34,211,238,0.25)', icon: 'code', radius: 20, connections: 1 },
  { id: 'trading-agent', name: 'Trading Agent', type: 'agent', status: 'online', color: '#F59E0B', glowColor: 'rgba(245,158,11,0.25)', icon: 'trending', radius: 20, connections: 1 },
  { id: 'research-agent', name: 'Research Agent', type: 'agent', status: 'online', color: '#3B82F6', glowColor: 'rgba(59,130,246,0.25)', icon: 'search', radius: 20, connections: 1 },
  { id: 'memory-agent', name: 'Memory Agent', type: 'agent', status: 'online', color: '#A855F7', glowColor: 'rgba(168,85,247,0.25)', icon: 'database', radius: 20, connections: 1 },
  { id: 'vision-agent', name: 'Vision Agent', type: 'agent', status: 'idle', color: '#EC4899', glowColor: 'rgba(236,72,153,0.25)', icon: 'eye', radius: 20, connections: 1 },
  { id: 'browser-agent', name: 'Browser Agent', type: 'agent', status: 'online', color: '#10B981', glowColor: 'rgba(16,185,129,0.25)', icon: 'globe', radius: 20, connections: 1 },
];

const links: InfraLink[] = [
  /* Core connections */
  { source: 'axe-core', target: 'axe-companion', type: 'core' },
  { source: 'axe-core', target: 'axe-intel', type: 'core' },
  /* Core to services */
  { source: 'axe-core', target: 'supabase', type: 'service' },
  { source: 'axe-core', target: 'cloudflare', type: 'service' },
  { source: 'axe-core', target: 'vercel', type: 'service' },
  { source: 'axe-core', target: 'railway', type: 'service' },
  { source: 'axe-core', target: 'resend', type: 'service' },
  /* Core to agents */
  { source: 'axe-core', target: 'coding-agent', type: 'agent' },
  { source: 'axe-core', target: 'trading-agent', type: 'agent' },
  { source: 'axe-core', target: 'research-agent', type: 'agent' },
  { source: 'axe-core', target: 'memory-agent', type: 'agent' },
  { source: 'axe-core', target: 'vision-agent', type: 'agent' },
  { source: 'axe-core', target: 'browser-agent', type: 'agent' },
  /* Companion to some agents */
  { source: 'axe-companion', target: 'coding-agent', type: 'agent' },
  { source: 'axe-companion', target: 'browser-agent', type: 'agent' },
  { source: 'axe-companion', target: 'memory-agent', type: 'agent' },
  /* Intel to some agents */
  { source: 'axe-intel', target: 'research-agent', type: 'agent' },
  { source: 'axe-intel', target: 'trading-agent', type: 'agent' },
  { source: 'axe-intel', target: 'vision-agent', type: 'agent' },
  /* Services inter-connect */
  { source: 'cloudflare', target: 'vercel', type: 'service' },
  { source: 'supabase', target: 'railway', type: 'service' },
];

/* ------------------------------------------------------------------ */
/*  ICON MAP                                                           */
/* ------------------------------------------------------------------ */

const iconMap: Record<string, React.ComponentType<{ size?: number; color?: string }>> = {
  cpu: Cpu,
  bot: Bot,
  brain: BrainCircuit,
  database: Database,
  cloud: Cloud,
  triangle: Triangle,
  train: TrainFront,
  mail: Mail,
  code: Code2,
  trending: TrendingUp,
  search: Search,
  eye: Eye,
  globe: Globe,
};

function NodeIcon({ icon, size, color }: { icon: string; size: number; color: string }) {
  const IconComp = iconMap[icon];
  if (!IconComp) return null;
  return <IconComp size={size} color={color} />;
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */

export default function Infrastructure() {
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const simulationRef = useRef<d3.Simulation<d3.SimulationNodeDatum, undefined> | null>(null);
  const [selectedNode, setSelectedNode] = useState<InfraNode | null>(null);
  const [zoomTransform, setZoomTransform] = useState<d3.ZoomTransform>(d3.zoomIdentity);

  const width = typeof window !== 'undefined' ? window.innerWidth : 1200;
  const height = typeof window !== 'undefined' ? window.innerHeight - 48 : 800;

  /* Init D3 simulation */
  useEffect(() => {
    if (!svgRef.current || !containerRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const g = svg.append('g').attr('class', 'graph-root');

    /* Arrow markers for animated particles */
    const defs = svg.append('defs');

    /* Glow filters */
    nodes.forEach((node) => {
      const filter = defs
        .append('filter')
        .attr('id', `glow-${node.id}`)
        .attr('x', '-50%')
        .attr('y', '-50%')
        .attr('width', '200%')
        .attr('height', '200%');
      filter.append('feGaussianBlur').attr('stdDeviation', node.type === 'core' ? '6' : '4').attr('result', 'coloredBlur');
      const merge = filter.append('feMerge');
      merge.append('feMergeNode').attr('in', 'coloredBlur');
      merge.append('feMergeNode').attr('in', 'SourceGraphic');
    });

    /* Particle gradient */
    const particleGrad = defs.append('radialGradient').attr('id', 'particle-grad').attr('cx', '50%').attr('cy', '50%').attr('r', '50%');
    particleGrad.append('stop').attr('offset', '0%').attr('stop-color', '#22D3EE').attr('stop-opacity', 1);
    particleGrad.append('stop').attr('offset', '100%').attr('stop-color', '#22D3EE').attr('stop-opacity', 0);

    /* Build simulation */
    const simNodes: any[] = nodes.map((n) => ({ ...n, x: width / 2 + (Math.random() - 0.5) * 200, y: height / 2 + (Math.random() - 0.5) * 200 }));
    const simLinks: any[] = links.map((l) => ({ ...l }));

    const simulation = d3
      .forceSimulation(simNodes)
      .force(
        'link',
        d3
          .forceLink(simLinks)
          .id((d: any) => d.id)
          .distance((d: any) => (d.type === 'core' ? 100 : d.type === 'service' ? 150 : 130))
      )
      .force('charge', d3.forceManyBody().strength((d: any) => (d.type === 'core' ? -800 : -400)))
      .force('center', d3.forceCenter(width / 2, height / 2))
      .force('collision', d3.forceCollide().radius((d: any) => d.radius + 15))
      .force('x', d3.forceX(width / 2).strength(0.05))
      .force('y', d3.forceY(height / 2).strength(0.05));

    simulationRef.current = simulation;

    /* Links */
    const linkGroup = g.append('g').attr('class', 'links');
    const linkEls = linkGroup
      .selectAll('line')
      .data(simLinks)
      .enter()
      .append('line')
      .attr('stroke', (d: any) => {
        if (d.type === 'core') return 'rgba(34,211,238,0.25)';
        if (d.type === 'service') return 'rgba(100,116,139,0.2)';
        return 'rgba(100,116,139,0.15)';
      })
      .attr('stroke-width', (d: any) => (d.type === 'core' ? 2 : 1))
      .attr('stroke-dasharray', (d: any) => (d.type === 'agent' ? '4,4' : 'none'));

    /* Animated particles on links */
    const particleGroup = g.append('g').attr('class', 'particles');
    const particles = particleGroup
      .selectAll('circle')
      .data(simLinks)
      .enter()
      .append('circle')
      .attr('r', 2.5)
      .attr('fill', '#22D3EE')
      .attr('opacity', 0.8)
      .attr('filter', 'url(#glow-axe-core)');

    /* Node groups */
    const nodeGroup = g.append('g').attr('class', 'nodes');
    const nodeEls = nodeGroup
      .selectAll('g')
      .data(simNodes)
      .enter()
      .append('g')
      .style('cursor', 'pointer')
      .call(
        d3
          .drag<SVGGElement, any>()
          .on('start', (event, d) => {
            if (!event.active) simulation.alphaTarget(0.3).restart();
            d.fx = d.x;
            d.fy = d.y;
          })
          .on('drag', (event, d) => {
            d.fx = event.x;
            d.fy = event.y;
          })
          .on('end', (event, d) => {
            if (!event.active) simulation.alphaTarget(0);
            d.fx = null;
            d.fy = null;
          })
      )
      .on('click', (_event, d) => {
        setSelectedNode(d);
      });

    /* Node outer glow circle */
    nodeEls
      .append('circle')
      .attr('r', (d: any) => d.radius + 8)
      .attr('fill', (d: any) => d.glowColor)
      .attr('opacity', 0.3)
      .attr('filter', (d: any) => `url(#glow-${d.id})`);

    /* Node main circle */
    nodeEls
      .append('circle')
      .attr('r', (d: any) => d.radius)
      .attr('fill', () => 'rgba(10,14,23,0.9)')
      .attr('stroke', (d: any) => d.color)
      .attr('stroke-width', (d: any) => (d.type === 'core' ? 2.5 : 1.5));

    /* Node icon (foreignObject for React icons) */
    nodeEls
      .append('foreignObject')
      .attr('x', () => -10)
      .attr('y', () => -10)
      .attr('width', 20)
      .attr('height', 20)
      .append('xhtml:div')
      .style('display', 'flex')
      .style('align-items', 'center')
      .style('justify-content', 'center')
      .style('width', '100%')
      .style('height', '100%')
      .html((d: any) => {
        const color = d.color;
        const size = 14;
        /* Simple SVG icons for foreignObject */
        const iconSvgs: Record<string, string> = {
          cpu: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M15 2v2M15 20v2M9 2v2M9 20v2M2 15h2M2 9h2M20 15h2M20 9h2"/></svg>`,
          bot: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="10" rx="2"/><circle cx="12" cy="5" r="2"/><path d="M12 7v4M8 16h8"/></svg>`,
          brain: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a7 7 0 0 1 7 7c0 3.5-2 6.5-5 8.5V18a2 2 0 0 1-2 2h0a2 2 0 0 1-2-2v-.5c-3-2-5-5-5-8.5a7 7 0 0 1 7-7z"/><path d="M12 2v6"/><path d="M9 13h6"/></svg>`,
          database: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 12c0 1.66 4 3 9 3s9-1.34 9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>`,
          cloud: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9z"/></svg>`,
          triangle: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/></svg>`,
          train: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="3" width="16" height="16" rx="2"/><path d="M4 11h16"/><path d="M12 3v8"/><path d="m8 19-2 3"/><path d="m18 22-2-3"/><path d="M8 15h0"/><path d="M16 15h0"/></svg>`,
          mail: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>`,
          code: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>`,
          trending: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>`,
          search: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>`,
          eye: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2.06 12s3.5-7 9.94-7 9.94 7 9.94 7-3.5 7-9.94 7S2.06 12 2.06 12z"/><circle cx="12" cy="12" r="3"/></svg>`,
          globe: `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>`,
        };
        return iconSvgs[d.icon] || iconSvgs.cpu;
      });

    /* Status dot */
    nodeEls
      .append('circle')
      .attr('cx', (d: any) => d.radius - 4)
      .attr('cy', (d: any) => -d.radius + 4)
      .attr('r', 4)
      .attr('fill', (d: any) => (d.status === 'online' ? '#10B981' : d.status === 'active' ? '#22D3EE' : '#6B7280'))
      .attr('stroke', '#05070A')
      .attr('stroke-width', 1.5);

    /* Labels */
    const labelGroup = g.append('g').attr('class', 'labels');
    const labels = labelGroup
      .selectAll('text')
      .data(simNodes)
      .enter()
      .append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', (d: any) => d.radius + 16)
      .attr('fill', '#F0F4F8')
      .attr('font-size', '10px')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('font-weight', '500')
      .text((d: any) => d.name);

    /* Type badge below label */
    const badgeGroup = g.append('g').attr('class', 'badges');
    const badges = badgeGroup
      .selectAll('text')
      .data(simNodes)
      .enter()
      .append('text')
      .attr('text-anchor', 'middle')
      .attr('dy', (d: any) => d.radius + 28)
      .attr('fill', (d: any) => (d.type === 'core' ? '#22D3EE' : d.type === 'service' ? '#8B9DBF' : '#4A5568'))
      .attr('font-size', '8px')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('letter-spacing', '0.08em')
      .attr('text-transform', 'uppercase')
      .text((d: any) => d.type);

    /* Simulation tick */
    simulation.on('tick', () => {
      linkEls
        .attr('x1', (d: any) => d.source.x)
        .attr('y1', (d: any) => d.source.y)
        .attr('x2', (d: any) => d.target.x)
        .attr('y2', (d: any) => d.target.y);

      nodeEls.attr('transform', (d: any) => `translate(${d.x},${d.y})`);
      labels.attr('x', (d: any) => d.x).attr('y', (d: any) => d.y);
      badges.attr('x', (d: any) => d.x).attr('y', (d: any) => d.y);

      /* Animate particles along links */
      const t = Date.now() / 1000;
      particles.attr('cx', (d: any) => {
        const progress = (t * 0.5 + Math.random() * 0.1) % 1;
        return d.source.x + (d.target.x - d.source.x) * progress;
      }).attr('cy', (d: any) => {
        const progress = (t * 0.5 + Math.random() * 0.1) % 1;
        return d.source.y + (d.target.y - d.source.y) * progress;
      });
    });

    /* Zoom behavior */
    const zoom = d3
      .zoom<SVGSVGElement, unknown>()
      .scaleExtent([0.3, 3])
      .on('zoom', (event) => {
        g.attr('transform', event.transform.toString());
        setZoomTransform(event.transform);
      });

    svg.call(zoom as any);

    return () => {
      simulation.stop();
      svg.selectAll('*').remove();
    };
  }, [width, height]);

  /* Controls */
  const handleZoomIn = useCallback(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.transition().duration(300).call(
      (d3.zoom().scaleExtent([0.3, 3]) as any).transform,
      zoomTransform.scale(zoomTransform.k * 1.3)
    );
  }, [zoomTransform]);

  const handleZoomOut = useCallback(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.transition().duration(300).call(
      (d3.zoom().scaleExtent([0.3, 3]) as any).transform,
      zoomTransform.scale(zoomTransform.k / 1.3)
    );
  }, [zoomTransform]);

  const handleFitView = useCallback(() => {
    if (!svgRef.current || !containerRef.current) return;
    const svg = d3.select(svgRef.current);
    const rect = containerRef.current.getBoundingClientRect();
    svg.transition().duration(500).call(
      (d3.zoom().scaleExtent([0.3, 3]) as any).transform,
      d3.zoomIdentity.translate(rect.width / 2, rect.height / 2).scale(0.85)
    );
  }, []);

  const handleReset = useCallback(() => {
    if (!svgRef.current) return;
    const svg = d3.select(svgRef.current);
    svg.transition().duration(500).call(
      (d3.zoom().scaleExtent([0.3, 3]) as any).transform,
      d3.zoomIdentity
    );
    if (simulationRef.current) {
      simulationRef.current.alpha(1).restart();
    }
    setSelectedNode(null);
  }, []);

  return (
    <motion.div
      className="relative w-full h-full overflow-hidden"
      style={{ backgroundColor: '#05070A' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
    >
      {/* Title overlay */}
      <div className="absolute top-4 left-6 z-10 pointer-events-none">
        <h1 className="text-page-title font-semibold" style={{ color: 'var(--text-primary)' }}>
          Infrastructure Map
        </h1>
        <p className="text-xs-custom mt-1" style={{ color: 'var(--text-muted)' }}>
          {nodes.length} nodes · {links.length} connections · Drag to rearrange
        </p>
      </div>

      {/* SVG Canvas */}
      <div ref={containerRef} className="w-full h-full">
        <svg
          ref={svgRef}
          width="100%"
          height="100%"
          style={{ backgroundColor: '#05070A', cursor: 'grab' }}
        />
      </div>

      {/* Controls */}
      <div
        className="absolute bottom-6 left-6 z-10 flex flex-col gap-2"
        style={{ backgroundColor: 'rgba(10,14,23,0.8)', borderRadius: '10px', padding: '6px', border: '1px solid rgba(255,255,255,0.05)' }}
      >
        <button
          onClick={handleZoomIn}
          className="p-2 rounded-lg transition-colors hover:bg-white/5"
          title="Zoom In"
        >
          <ZoomIn size={16} style={{ color: 'var(--text-secondary)' }} />
        </button>
        <button
          onClick={handleZoomOut}
          className="p-2 rounded-lg transition-colors hover:bg-white/5"
          title="Zoom Out"
        >
          <ZoomOut size={16} style={{ color: 'var(--text-secondary)' }} />
        </button>
        <button
          onClick={handleFitView}
          className="p-2 rounded-lg transition-colors hover:bg-white/5"
          title="Fit to View"
        >
          <Maximize2 size={16} style={{ color: 'var(--text-secondary)' }} />
        </button>
        <button
          onClick={handleReset}
          className="p-2 rounded-lg transition-colors hover:bg-white/5"
          title="Reset Layout"
        >
          <RotateCcw size={16} style={{ color: 'var(--text-secondary)' }} />
        </button>
      </div>

      {/* Legend */}
      <div
        className="absolute top-4 right-6 z-10"
        style={{ backgroundColor: 'rgba(10,14,23,0.8)', borderRadius: '10px', padding: '12px', border: '1px solid rgba(255,255,255,0.05)' }}
      >
        <div className="text-[10px] font-mono uppercase tracking-wider mb-2" style={{ color: 'var(--text-muted)' }}>Legend</div>
        <div className="space-y-1.5">
          {[
            { label: 'Core', color: '#22D3EE' },
            { label: 'Service', color: '#8B9DBF' },
            { label: 'Agent', color: '#4A5568' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-2">
              <span className="rounded-full" style={{ width: '7px', height: '7px', backgroundColor: item.color }} />
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Selected node detail */}
      {selectedNode && (
        <motion.div
          className="absolute bottom-6 right-6 z-10"
          style={{
            backgroundColor: 'rgba(10,14,23,0.9)',
            borderRadius: '12px',
            padding: '16px',
            border: `1px solid ${selectedNode.glowColor}`,
            minWidth: '220px',
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
        >
          <div className="flex items-center gap-3 mb-3">
            <div
              className="rounded-lg flex items-center justify-center"
              style={{ width: '36px', height: '36px', backgroundColor: selectedNode.glowColor }}
            >
              <NodeIcon icon={selectedNode.icon} size={18} color={selectedNode.color} />
            </div>
            <div>
              <div className="text-body font-medium" style={{ color: 'var(--text-primary)' }}>{selectedNode.name}</div>
              <div className="flex items-center gap-2">
                <span className="rounded-full" style={{ width: '6px', height: '6px', backgroundColor: selectedNode.status === 'online' ? '#10B981' : selectedNode.status === 'active' ? '#22D3EE' : '#6B7280' }} />
                <span className="text-xs-custom" style={{ color: 'var(--text-secondary)' }}>{selectedNode.status}</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-xs-custom">
            <div style={{ color: 'var(--text-muted)' }}>Type</div>
            <div className="text-right capitalize" style={{ color: 'var(--text-secondary)' }}>{selectedNode.type}</div>
            <div style={{ color: 'var(--text-muted)' }}>Connections</div>
            <div className="text-right" style={{ color: 'var(--accent-cyan)' }}>{selectedNode.connections}</div>
            <div style={{ color: 'var(--text-muted)' }}>Status</div>
            <div className="text-right capitalize" style={{ color: 'var(--text-secondary)' }}>{selectedNode.status}</div>
          </div>
          <button
            onClick={() => setSelectedNode(null)}
            className="mt-3 text-[10px] uppercase tracking-wider transition-colors hover:opacity-70"
            style={{ color: 'var(--text-muted)' }}
          >
            Close
          </button>
        </motion.div>
      )}
    </motion.div>
  );
}
