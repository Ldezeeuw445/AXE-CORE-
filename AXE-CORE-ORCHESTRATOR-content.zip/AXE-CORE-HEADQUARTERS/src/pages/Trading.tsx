import { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  TrendingDown,
  ExternalLink,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Wallet,
  BarChart3,
  Layers,
  Clock,
  AlertCircle,
  AlignLeft,
} from 'lucide-react';

/* ------------------------------------------------------------------ */
/*  MOCK DATA                                                          */
/* ------------------------------------------------------------------ */

interface WatchlistItem {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  sparkline: number[];
}

interface OrderBookEntry {
  price: number;
  size: number;
  total: number;
}

interface Trade {
  id: string;
  pair: string;
  side: 'BUY' | 'SELL';
  price: number;
  size: number;
  timestamp: string;
}

interface Position {
  pair: string;
  side: 'LONG' | 'SHORT';
  size: number;
  entryPrice: number;
  markPrice: number;
  pnl: number;
  pnlPercent: number;
}

const WATCHLIST: WatchlistItem[] = [
  { symbol: 'BTC/USDT', name: 'Bitcoin', price: 97245.32, change24h: 2.34, sparkline: [95500, 96200, 95800, 96800, 97200, 96500, 97000, 97400, 96800, 97245] },
  { symbol: 'ETH/USDT', name: 'Ethereum', price: 3482.15, change24h: -1.12, sparkline: [3520, 3500, 3480, 3495, 3470, 3460, 3485, 3475, 3490, 3482] },
  { symbol: 'SOL/USDT', name: 'Solana', price: 198.42, change24h: 5.67, sparkline: [188, 190, 192, 189, 195, 193, 196, 194, 197, 198] },
  { symbol: 'XRP/USDT', name: 'Ripple', price: 2.847, change24h: -0.45, sparkline: [2.87, 2.86, 2.85, 2.86, 2.84, 2.85, 2.845, 2.85, 2.848, 2.847] },
  { symbol: 'DOGE/USDT', name: 'Dogecoin', price: 0.3842, change24h: 8.91, sparkline: [0.35, 0.36, 0.355, 0.37, 0.365, 0.375, 0.38, 0.378, 0.382, 0.384] },
  { symbol: 'LINK/USDT', name: 'Chainlink', price: 21.47, change24h: 1.23, sparkline: [21.1, 21.2, 21.15, 21.3, 21.25, 21.35, 21.4, 21.3, 21.45, 21.47] },
  { symbol: 'AVAX/USDT', name: 'Avalanche', price: 38.92, change24h: -2.56, sparkline: [39.8, 39.5, 39.2, 39.0, 38.8, 38.7, 38.9, 39.1, 38.85, 38.92] },
  { symbol: 'MATIC/USDT', name: 'Polygon', price: 0.5247, change24h: 0.89, sparkline: [0.518, 0.52, 0.519, 0.522, 0.521, 0.523, 0.525, 0.524, 0.526, 0.5247] },
];

const ORDER_BOOK_BIDS: OrderBookEntry[] = [
  { price: 97243.5, size: 0.45, total: 43759.57 },
  { price: 97241.2, size: 1.23, total: 119606.67 },
  { price: 97238.8, size: 0.78, total: 75846.26 },
  { price: 97236.0, size: 2.15, total: 209057.4 },
  { price: 97234.5, size: 0.32, total: 31115.04 },
  { price: 97232.1, size: 1.85, total: 179879.38 },
  { price: 97230.0, size: 0.95, total: 92368.5 },
  { price: 97228.7, size: 3.42, total: 332522.15 },
];

const ORDER_BOOK_ASKS: OrderBookEntry[] = [
  { price: 97247.0, size: 0.82, total: 79742.54 },
  { price: 97249.5, size: 1.56, total: 151709.22 },
  { price: 97252.0, size: 0.34, total: 33065.68 },
  { price: 97254.8, size: 2.78, total: 270368.34 },
  { price: 97257.0, size: 0.65, total: 63217.05 },
  { price: 97260.5, size: 1.12, total: 108931.76 },
  { price: 97263.0, size: 0.48, total: 46686.24 },
  { price: 97265.5, size: 1.95, total: 189667.72 },
];

const RECENT_TRADES: Trade[] = [
  { id: 't1', pair: 'BTC/USDT', side: 'BUY', price: 97245.32, size: 0.124, timestamp: '14:32:05' },
  { id: 't2', pair: 'BTC/USDT', side: 'SELL', price: 97243.18, size: 0.356, timestamp: '14:31:58' },
  { id: 't3', pair: 'ETH/USDT', side: 'BUY', price: 3482.15, size: 2.450, timestamp: '14:31:42' },
  { id: 't4', pair: 'BTC/USDT', side: 'BUY', price: 97241.50, size: 0.890, timestamp: '14:31:35' },
  { id: 't5', pair: 'SOL/USDT', side: 'SELL', price: 198.42, size: 15.20, timestamp: '14:31:18' },
  { id: 't6', pair: 'BTC/USDT', side: 'BUY', price: 97238.80, size: 0.220, timestamp: '14:31:05' },
  { id: 't7', pair: 'ETH/USDT', side: 'SELL', price: 3481.92, size: 1.100, timestamp: '14:30:48' },
  { id: 't8', pair: 'BTC/USDT', side: 'SELL', price: 97240.15, size: 0.560, timestamp: '14:30:22' },
];

const POSITIONS: Position[] = [
  { pair: 'BTC/USDT', side: 'LONG', size: 0.5, entryPrice: 96500.0, markPrice: 97245.32, pnl: 372.66, pnlPercent: 0.77 },
  { pair: 'ETH/USDT', side: 'LONG', size: 4.0, entryPrice: 3520.0, markPrice: 3482.15, pnl: -151.40, pnlPercent: -1.08 },
  { pair: 'SOL/USDT', side: 'LONG', size: 25.0, entryPrice: 192.5, markPrice: 198.42, pnl: 148.0, pnlPercent: 3.08 },
  { pair: 'XRP/USDT', side: 'SHORT', size: 1000, entryPrice: 2.92, markPrice: 2.847, pnl: 73.0, pnlPercent: 2.50 },
];

const AREA_CHART_DATA = [
  96200, 96400, 96100, 96700, 96500, 96900, 96800, 97100, 97000, 97200,
  97100, 97300, 97250, 97400, 97300, 97150, 97250, 97100, 97300, 97245,
];

/* ------------------------------------------------------------------ */
/*  MINI SPARKLINE                                                     */
/* ------------------------------------------------------------------ */

function Sparkline({ data, width = 60, height = 20, color }: { data: number[]; width?: number; height?: number; color: string }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => `${(i / (data.length - 1)) * width},${height - ((v - min) / range) * height}`).join(' ');
  const areaPoints = `0,${height} ${points} ${width},${height}`;
  return (
    <svg width={width} height={height}>
      <polygon points={areaPoints} fill={`${color}20`} />
      <polyline points={points} fill="none" stroke={color} strokeWidth={1.2} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/*  AREA CHART                                                         */
/* ------------------------------------------------------------------ */

function AreaChart({ data, width = 500, height = 180 }: { data: number[]; width?: number; height?: number }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => `${(i / (data.length - 1)) * width},${height - ((v - min) / range) * height * 0.85 - height * 0.05}`);
  const areaPoints = `0,${height} ${points.join(' ')} ${width},${height}`;
  const linePoints = points.join(' ');
  const midPrice = data[data.length - 1];

  return (
    <div className="relative">
      <svg width={width} height={height}>
        <defs>
          <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#22D3EE" stopOpacity={0.25} />
            <stop offset="100%" stopColor="#22D3EE" stopOpacity={0} />
          </linearGradient>
        </defs>
        <polygon points={areaPoints} fill="url(#areaGrad)" />
        <polyline points={linePoints} fill="none" stroke="#22D3EE" strokeWidth={1.5} strokeLinecap="round" strokeLinejoin="round" />
        {/* Current price line */}
        <line
          x1={0} y1={height - ((midPrice - min) / range) * height * 0.85 - height * 0.05}
          x2={width} y2={height - ((midPrice - min) / range) * height * 0.85 - height * 0.05}
          stroke="#22D3EE"
          strokeWidth={0.5}
          strokeDasharray="4,4"
          opacity={0.5}
        />
      </svg>
      <div
        className="absolute text-[10px] font-mono"
        style={{ right: 8, top: height - ((midPrice - min) / range) * height * 0.85 - height * 0.05 - 14, color: '#22D3EE' }}
      >
        {midPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN COMPONENT                                                     */
/* ------------------------------------------------------------------ */

export default function Trading() {
  const [iframeFailed, setIframeFailed] = useState(false);
  const [selectedPair, setSelectedPair] = useState('BTC/USDT');

  const totalEquity = 124580.45;
  const dayPnl = 1247.82;
  const dayPnlPercent = 1.01;
  const availableMargin = 45230.18;

  const handleIframeError = useCallback(() => {
    setIframeFailed(true);
  }, []);

  /* Simulate iframe failure check */
  useEffect(() => {
    const timer = setTimeout(() => {
      setIframeFailed(true);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <motion.div
      className="h-full flex flex-col overflow-hidden"
      style={{ backgroundColor: 'var(--bg-base)' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      {/* Top: Portfolio Bar */}
      <div
        className="flex-shrink-0 flex items-center gap-6 px-6 py-3"
        style={{ borderBottom: '1px solid var(--border-subtle)', backgroundColor: 'var(--bg-surface)' }}
      >
        <div className="flex items-center gap-2">
          <Wallet size={14} color="var(--accent-cyan)" />
          <span className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Equity</span>
          <span className="text-body font-mono font-semibold" style={{ color: 'var(--text-primary)' }}>
            ${totalEquity.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Activity size={14} color={dayPnl >= 0 ? 'var(--success)' : 'var(--error)'} />
          <span className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>P&L (24h)</span>
          <span
            className="text-body font-mono font-semibold flex items-center gap-1"
            style={{ color: dayPnl >= 0 ? 'var(--success)' : 'var(--error)' }}
          >
            {dayPnl >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
            ${Math.abs(dayPnl).toLocaleString(undefined, { minimumFractionDigits: 2 })} ({dayPnlPercent}%)
          </span>
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <Layers size={14} color="var(--accent-blue)" />
          <span className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Margin</span>
          <span className="text-body font-mono" style={{ color: 'var(--text-primary)' }}>
            ${availableMargin.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </span>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Watchlist */}
        <div
          className="flex-shrink-0 overflow-y-auto"
          style={{
            width: '260px',
            borderRight: '1px solid var(--border-subtle)',
            backgroundColor: 'var(--bg-surface)',
          }}
        >
          <div
            className="px-3 py-2.5 flex items-center gap-2 sticky top-0 z-10"
            style={{ backgroundColor: 'var(--bg-surface)', borderBottom: '1px solid var(--border-subtle)' }}
          >
            <BarChart3 size={12} color="var(--accent-cyan)" />
            <span className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'var(--text-primary)' }}>
              Watchlist
            </span>
          </div>
          <div className="divide-y divide-[rgba(255,255,255,0.03)]">
            {WATCHLIST.map((item) => (
              <button
                key={item.symbol}
                onClick={() => setSelectedPair(item.symbol)}
                className="w-full px-3 py-2.5 text-left transition-colors hover:bg-white/[0.02]"
                style={{
                  backgroundColor: selectedPair === item.symbol ? 'rgba(34,211,238,0.04)' : 'transparent',
                  borderLeft: selectedPair === item.symbol ? '2px solid var(--accent-cyan)' : '2px solid transparent',
                }}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>{item.symbol}</span>
                  <span
                    className="text-[10px] font-mono flex items-center gap-0.5"
                    style={{ color: item.change24h >= 0 ? 'var(--success)' : 'var(--error)' }}
                  >
                    {item.change24h >= 0 ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                    {item.change24h >= 0 ? '+' : ''}{item.change24h.toFixed(2)}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>
                    ${item.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </span>
                  <Sparkline
                    data={item.sparkline}
                    width={55}
                    height={16}
                    color={item.change24h >= 0 ? '#10B981' : '#EF4444'}
                  />
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Center: Chart / Iframe */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Pair Header */}
          <div
            className="flex-shrink-0 flex items-center gap-4 px-4 py-2.5"
            style={{ borderBottom: '1px solid var(--border-subtle)' }}
          >
            <span className="text-section-title font-semibold" style={{ color: 'var(--text-primary)' }}>
              {selectedPair}
            </span>
            <span className="text-mono-lg font-mono" style={{ color: 'var(--accent-cyan)' }}>
              ${WATCHLIST.find((w) => w.symbol === selectedPair)?.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
            </span>
            <span
              className="text-xs-custom font-mono"
              style={{
                color: (WATCHLIST.find((w) => w.symbol === selectedPair)?.change24h || 0) >= 0 ? 'var(--success)' : 'var(--error)',
              }}
            >
              {(WATCHLIST.find((w) => w.symbol === selectedPair)?.change24h || 0) >= 0 ? '+' : ''}
              {WATCHLIST.find((w) => w.symbol === selectedPair)?.change24h.toFixed(2)}%
            </span>
            {!iframeFailed && (
              <button
                onClick={() => window.open('https://krypt.cc', '_blank')}
                className="ml-auto flex items-center gap-1.5 text-[10px] px-2 py-1 rounded transition-colors hover:bg-white/5"
                style={{ color: 'var(--accent-cyan)', border: '1px solid rgba(34,211,238,0.2)' }}
              >
                <ExternalLink size={10} />
                Open krypt.cc
              </button>
            )}
          </div>

          {/* Chart / iframe area */}
          <div className="flex-1 relative overflow-hidden" style={{ backgroundColor: '#05070A' }}>
            {!iframeFailed ? (
              <>
                <iframe
                  src="https://krypt.cc"
                  className="w-full h-full border-0"
                  title="krypt.cc Trading"
                  onError={handleIframeError}
                  sandbox="allow-scripts allow-same-origin allow-popups"
                />
                {/* Overlay to detect iframe failure */}
                <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 1 }}>
                  <div
                    className="absolute bottom-4 left-4 text-[10px] font-mono px-2 py-1 rounded"
                    style={{ backgroundColor: 'rgba(10,14,23,0.8)', color: 'var(--text-muted)' }}
                  >
                    Loading krypt.cc...
                  </div>
                </div>
              </>
            ) : (
              /* Fallback Trading View */
              <div className="w-full h-full flex flex-col overflow-y-auto">
                {/* Area Chart */}
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-[10px] uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>Price Chart</span>
                    <span className="text-[10px] font-mono" style={{ color: 'var(--text-muted)' }}>1H</span>
                  </div>
                  <AreaChart data={AREA_CHART_DATA} width={520} height={160} />
                </div>

                {/* Order Book + Trades side by side */}
                <div className="flex-1 grid grid-cols-2 gap-0" style={{ borderTop: '1px solid var(--border-subtle)' }}>
                  {/* Order Book */}
                  <div className="overflow-hidden" style={{ borderRight: '1px solid var(--border-subtle)' }}>
                    <div
                      className="px-3 py-2 flex items-center gap-2 sticky top-0 z-10"
                      style={{ backgroundColor: 'var(--bg-base)', borderBottom: '1px solid var(--border-subtle)' }}
                    >
                      <AlignLeft size={10} color="var(--text-muted)" />
                      <span className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'var(--text-muted)' }}>
                        Order Book
                      </span>
                    </div>
                    {/* Asks */}
                    <div className="px-2">
                      {ORDER_BOOK_ASKS.map((ask, i) => (
                        <div key={`ask-${i}`} className="flex items-center text-[10px] font-mono py-0.5">
                          <span className="flex-1" style={{ color: 'var(--error)' }}>{ask.price.toFixed(1)}</span>
                          <span className="w-16 text-right" style={{ color: 'var(--text-secondary)' }}>{ask.size.toFixed(2)}</span>
                          <div className="w-16 h-3 relative ml-2">
                            <div className="absolute inset-0 rounded-sm" style={{ backgroundColor: 'rgba(239,68,68,0.08)', width: `${(ask.total / 350000) * 100}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                    {/* Spread */}
                    <div
                      className="px-2 py-1 my-1 text-center text-[10px] font-mono"
                      style={{ backgroundColor: 'rgba(255,255,255,0.02)', color: 'var(--text-muted)' }}
                    >
                      Spread: {(ORDER_BOOK_ASKS[0].price - ORDER_BOOK_BIDS[0].price).toFixed(1)}
                    </div>
                    {/* Bids */}
                    <div className="px-2">
                      {ORDER_BOOK_BIDS.map((bid, i) => (
                        <div key={`bid-${i}`} className="flex items-center text-[10px] font-mono py-0.5">
                          <span className="flex-1" style={{ color: 'var(--success)' }}>{bid.price.toFixed(1)}</span>
                          <span className="w-16 text-right" style={{ color: 'var(--text-secondary)' }}>{bid.size.toFixed(2)}</span>
                          <div className="w-16 h-3 relative ml-2">
                            <div className="absolute inset-0 rounded-sm" style={{ backgroundColor: 'rgba(16,185,129,0.08)', width: `${(bid.total / 350000) * 100}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recent Trades */}
                  <div className="overflow-hidden">
                    <div
                      className="px-3 py-2 flex items-center gap-2 sticky top-0 z-10"
                      style={{ backgroundColor: 'var(--bg-base)', borderBottom: '1px solid var(--border-subtle)' }}
                    >
                      <Clock size={10} color="var(--text-muted)" />
                      <span className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'var(--text-muted)' }}>
                        Recent Trades
                      </span>
                    </div>
                    <div className="px-2">
                      {RECENT_TRADES.map((trade) => (
                        <div key={trade.id} className="flex items-center text-[10px] font-mono py-0.5">
                          <span className="w-14" style={{ color: 'var(--text-muted)' }}>{trade.timestamp}</span>
                          <span
                            className="w-8 font-medium"
                            style={{ color: trade.side === 'BUY' ? 'var(--success)' : 'var(--error)' }}
                          >
                            {trade.side}
                          </span>
                          <span className="flex-1 text-right" style={{ color: 'var(--text-primary)' }}>
                            {trade.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                          </span>
                          <span className="w-14 text-right" style={{ color: 'var(--text-secondary)' }}>
                            {trade.size.toFixed(3)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Fallback notice */}
                <div
                  className="flex items-center gap-2 px-4 py-2"
                  style={{ backgroundColor: 'rgba(245,158,11,0.05)', borderTop: '1px solid rgba(245,158,11,0.1)' }}
                >
                  <AlertCircle size={12} color="var(--warning)" />
                  <span className="text-[10px]" style={{ color: 'var(--warning)' }}>
                    krypt.cc could not be loaded. Showing simulated data.
                  </span>
                  <button
                    onClick={() => window.open('https://krypt.cc', '_blank')}
                    className="ml-auto flex items-center gap-1 text-[10px] px-2 py-0.5 rounded transition-colors hover:bg-white/5"
                    style={{ color: 'var(--accent-cyan)' }}
                  >
                    <ExternalLink size={9} />
                    Open in new tab
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right: Order Panel */}
        <div
          className="flex-shrink-0 overflow-y-auto"
          style={{
            width: '240px',
            borderLeft: '1px solid var(--border-subtle)',
            backgroundColor: 'var(--bg-surface)',
          }}
        >
          {/* Quick Order */}
          <div className="p-3" style={{ borderBottom: '1px solid var(--border-subtle)' }}>
            <span className="text-[10px] uppercase tracking-wider font-medium block mb-2" style={{ color: 'var(--text-muted)' }}>
              Quick Order
            </span>
            <div className="flex gap-2 mb-2">
              <button
                className="flex-1 py-2 rounded-lg text-xs font-medium transition-opacity hover:opacity-80"
                style={{ backgroundColor: 'rgba(16,185,129,0.15)', color: '#10B981' }}
              >
                Buy / Long
              </button>
              <button
                className="flex-1 py-2 rounded-lg text-xs font-medium transition-opacity hover:opacity-80"
                style={{ backgroundColor: 'rgba(239,68,68,0.15)', color: '#EF4444' }}
              >
                Sell / Short
              </button>
            </div>
            <div className="space-y-2">
              <div>
                <label className="text-[10px] block mb-1" style={{ color: 'var(--text-muted)' }}>Price</label>
                <input
                  type="text"
                  defaultValue="97245.32"
                  className="w-full px-2 py-1.5 rounded-lg text-xs font-mono outline-none"
                  style={{
                    backgroundColor: 'var(--bg-base)',
                    border: '1px solid var(--border-subtle)',
                    color: 'var(--text-primary)',
                  }}
                />
              </div>
              <div>
                <label className="text-[10px] block mb-1" style={{ color: 'var(--text-muted)' }}>Size</label>
                <input
                  type="text"
                  defaultValue="0.10"
                  className="w-full px-2 py-1.5 rounded-lg text-xs font-mono outline-none"
                  style={{
                    backgroundColor: 'var(--bg-base)',
                    border: '1px solid var(--border-subtle)',
                    color: 'var(--text-primary)',
                  }}
                />
              </div>
            </div>
          </div>

          {/* Positions */}
          <div className="p-3">
            <span className="text-[10px] uppercase tracking-wider font-medium block mb-2" style={{ color: 'var(--text-muted)' }}>
              Positions ({POSITIONS.length})
            </span>
            <div className="space-y-2">
              {POSITIONS.map((pos) => (
                <div
                  key={pos.pair}
                  className="p-2.5 rounded-lg"
                  style={{ backgroundColor: 'rgba(255,255,255,0.02)', border: '1px solid var(--border-subtle)' }}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>{pos.pair}</span>
                    <span
                      className="text-[9px] px-1.5 py-0.5 rounded font-medium"
                      style={{
                        backgroundColor: pos.side === 'LONG' ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)',
                        color: pos.side === 'LONG' ? '#10B981' : '#EF4444',
                      }}
                    >
                      {pos.side}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[10px] font-mono">
                    <span style={{ color: 'var(--text-muted)' }}>{pos.size} @ {pos.entryPrice.toLocaleString()}</span>
                    <span
                      className="flex items-center gap-0.5"
                      style={{ color: pos.pnl >= 0 ? 'var(--success)' : 'var(--error)' }}
                    >
                      {pos.pnl >= 0 ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                      ${Math.abs(pos.pnl).toFixed(2)} ({pos.pnlPercent >= 0 ? '+' : ''}{pos.pnlPercent.toFixed(2)}%)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
