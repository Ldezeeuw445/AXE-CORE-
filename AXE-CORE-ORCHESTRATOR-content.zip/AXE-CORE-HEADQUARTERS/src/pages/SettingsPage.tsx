import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { WidgetCard } from '@/components/widgets/WidgetCard';
import { StatusBadge } from '@/components/widgets/StatusBadge';
import { useVoiceStore } from '@/store/voiceStore';
import {
  Palette, Volume2, Keyboard, Shield, Bell, Cpu, User, Globe,
  Key, Eye, EyeOff, Mic, Save, ExternalLink, MessageSquare, Check, X, AlertTriangle, MicOff,
} from 'lucide-react';

const settingsGroups = [
  {
    title: 'Appearance', icon: Palette,
    items: [
      { label: 'Theme', value: 'Dark (AXE)' },
      { label: 'Accent color', value: 'Cyan' },
      { label: 'Font size', value: 'Medium' },
      { label: 'Animations', value: 'Enabled' },
    ],
  },
  {
    title: 'Voice', icon: Volume2,
    items: [
      { label: 'Voice input', value: 'Enabled' },
      { label: 'Wake word', value: "'Hey AXE'" },
      { label: 'Voice output', value: 'Enabled' },
      { label: 'Language', value: 'Dutch / English' },
    ],
  },
  {
    title: 'Keyboard', icon: Keyboard,
    items: [
      { label: 'Shortcuts', value: 'Enabled' },
      { label: 'Command palette', value: '⌘K' },
      { label: 'Voice toggle', value: '⌘⇧A' },
    ],
  },
  {
    title: 'Security', icon: Shield,
    items: [
      { label: '2FA', value: 'Enabled' },
      { label: 'Session timeout', value: '30 min' },
      { label: 'API key rotation', value: 'Auto (7d)' },
    ],
  },
  {
    title: 'Notifications', icon: Bell,
    items: [
      { label: 'Desktop notifications', value: 'Enabled' },
      { label: 'Sound alerts', value: 'Minimal' },
      { label: 'Focus mode', value: '2-4 PM daily' },
    ],
  },
  {
    title: 'System', icon: Cpu,
    items: [
      { label: 'Auto-update', value: 'Enabled' },
      { label: 'Telemetry', value: 'Disabled' },
      { label: 'Debug mode', value: 'Off' },
    ],
  },
  {
    title: 'Profile', icon: User,
    items: [
      { label: 'Name', value: 'Alex Chen' },
      { label: 'Email', value: 'alex@axe.dev' },
      { label: 'Timezone', value: 'Asia/Kolkata' },
    ],
  },
  {
    title: 'Integrations', icon: Globe,
    items: [
      { label: 'GitHub', value: 'Connected' },
      { label: 'Slack', value: 'Connected' },
      { label: 'Notion', value: 'Connected' },
    ],
  },
];

export default function SettingsPage() {
  const voice = useVoiceStore();
  const [keyInput, setKeyInput] = useState(voice.apiKey);
  const [showKey, setShowKey] = useState(false);
  const [saved, setSaved] = useState(false);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    voice.checkMicPermission();
  }, []);

  const handleSaveKey = () => {
    voice.setApiKey(keyInput);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleTestKey = async () => {
    if (!voice.apiKey) return;
    setTesting(true);
    await voice.testApiKey();
    setTesting(false);
  };

  const handleTestVoice = () => {
    if (voice.voiceStatus === 'idle') {
      voice.startListening();
    } else {
      voice.stopListening();
    }
  };

  return (
    <motion.div
      className="p-6 h-full overflow-y-auto"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
    >
      <h1 className="text-page-title font-semibold mb-6" style={{ color: 'var(--text-primary)' }}>
        System Settings
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl">
        {/* AI Configuration — Full Width */}
        <motion.div className="md:col-span-2" initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0 }}>
          <WidgetCard title="AI Configuration" headerAction={<Key size={16} style={{ color: 'var(--accent-cyan)' }} />}>
            <div className="space-y-4">
              {/* Mic Permission Status */}
              <div className="flex items-center gap-3 p-2 rounded-lg" style={{ backgroundColor: '#0A0A0A', border: '1px solid rgba(255,255,255,0.04)' }}>
                <span className="text-xs-custom" style={{ color: 'var(--text-muted)' }}>Microphone:</span>
                {voice.micPermission === 'granted' ? (
                  <span className="text-xs-custom flex items-center gap-1" style={{ color: 'var(--success)' }}>
                    <Check size={12} /> Allowed
                  </span>
                ) : voice.micPermission === 'denied' ? (
                  <span className="text-xs-custom flex items-center gap-1" style={{ color: 'var(--error)' }}>
                    <MicOff size={12} /> Blocked — Click lock icon in address bar → Allow
                  </span>
                ) : (
                  <span className="text-xs-custom flex items-center gap-1" style={{ color: 'var(--warning)' }}>
                    <AlertTriangle size={12} /> Not requested yet
                  </span>
                )}
                <span className="text-xs-custom ml-2" style={{ color: 'var(--text-muted)' }}>
                  Speech support: {voice.recognitionSupported ? '✅' : '❌'}
                </span>
              </div>

              {/* API Key Input */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-small font-medium" style={{ color: 'var(--text-primary)' }}>
                    Moonshot API Key
                  </label>
                  <div className="flex items-center gap-2">
                    {voice.apiKeyValid === true && (
                      <span className="text-xs-custom flex items-center gap-1" style={{ color: 'var(--success)' }}>
                        <Check size={12} /> Working
                      </span>
                    )}
                    {voice.apiKeyValid === false && (
                      <span className="text-xs-custom flex items-center gap-1" style={{ color: 'var(--error)' }}>
                        <X size={12} /> Failed
                      </span>
                    )}
                    <StatusBadge
                      variant={voice.apiKey ? 'online' : 'offline'}
                      label={voice.apiKey ? 'Set' : 'Not Set'}
                      size="sm"
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type={showKey ? 'text' : 'password'}
                      value={keyInput}
                      onChange={(e) => setKeyInput(e.target.value)}
                      placeholder="sk-xxxxxxxxxxxxxxxxxxxxxxxx"
                      className="w-full px-3 py-2 rounded-lg text-small font-mono-data outline-none transition-all"
                      style={{
                        backgroundColor: '#0A0A0A',
                        border: '1px solid rgba(255,255,255,0.06)',
                        color: 'var(--text-primary)',
                      }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = 'var(--border-active)'; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)'; }}
                    />
                    <button className="absolute right-2 top-1/2 -translate-y-1/2" onClick={() => setShowKey(!showKey)} style={{ color: 'var(--text-muted)' }}>
                      {showKey ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                  <button
                    onClick={handleSaveKey}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-small font-medium transition-all"
                    style={{
                      backgroundColor: saved ? 'rgba(16,185,129,0.15)' : 'var(--bg-active)',
                      border: `1px solid ${saved ? 'rgba(16,185,129,0.3)' : 'var(--border-active)'}`,
                      color: saved ? 'var(--success)' : 'var(--accent-cyan)',
                    }}
                  >
                    <Save size={14} />
                    {saved ? 'Saved!' : 'Save'}
                  </button>
                </div>
                <p className="text-xs-custom mt-1.5" style={{ color: 'var(--text-muted)' }}>
                  Get your key from{' '}
                  <a href="https://platform.moonshot.cn" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-0.5" style={{ color: 'var(--accent-cyan)' }}>
                    platform.moonshot.cn <ExternalLink size={10} />
                  </a>{' '}
                  · Stored locally in your browser
                </p>
              </div>

              {/* Test API Key Button */}
              <div className="flex items-center gap-3">
                <button
                  onClick={handleTestKey}
                  disabled={testing || !voice.apiKey}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg text-small font-medium transition-all"
                  style={{
                    backgroundColor: voice.apiKeyValid === true ? 'rgba(16,185,129,0.1)' : 'var(--bg-active)',
                    border: `1px solid ${voice.apiKeyValid === true ? 'rgba(16,185,129,0.3)' : 'var(--border-active)'}`,
                    color: voice.apiKeyValid === true ? 'var(--success)' : 'var(--accent-cyan)',
                    opacity: testing || !voice.apiKey ? 0.5 : 1,
                    cursor: testing || !voice.apiKey ? 'not-allowed' : 'pointer',
                  }}
                >
                  {testing ? (
                    <span className="flex items-center gap-1">
                      <span className="animate-spin inline-block w-3 h-3 border-2 border-current border-t-transparent rounded-full" />
                      Testing...
                    </span>
                  ) : (
                    <>
                      <Check size={14} />
                      Test API Key
                    </>
                  )}
                </button>
                <span className="text-xs-custom" style={{ color: 'var(--text-muted)' }}>
                  {voice.apiKeyValid === true
                    ? 'Your API key is working correctly!'
                    : voice.apiKeyValid === false
                      ? 'API key test failed. Check the error below.'
                      : 'Click to verify your key works'}
                </span>
              </div>

              {/* Divider */}
              <div style={{ borderTop: '1px solid rgba(255,255,255,0.04)' }} />

              {/* Model Info */}
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <span className="text-xs-custom block mb-1" style={{ color: 'var(--text-muted)' }}>Model</span>
                  <span className="text-small font-mono-data" style={{ color: 'var(--text-primary)' }}>moonshot-v1-8k</span>
                </div>
                <div>
                  <span className="text-xs-custom block mb-1" style={{ color: 'var(--text-muted)' }}>Language</span>
                  <span className="text-small" style={{ color: 'var(--text-primary)' }}>Dutch / English</span>
                </div>
                <div>
                  <span className="text-xs-custom block mb-1" style={{ color: 'var(--text-muted)' }}>Temperature</span>
                  <span className="text-small font-mono-data" style={{ color: 'var(--text-primary)' }}>0.70</span>
                </div>
              </div>

              {/* Test Voice Button */}
              <div className="flex items-center gap-3">
                <button
                  onClick={handleTestVoice}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg text-small font-medium transition-all"
                  style={{
                    backgroundColor: voice.voiceStatus !== 'idle' ? 'rgba(239,68,68,0.1)' : 'var(--bg-active)',
                    border: `1px solid ${voice.voiceStatus !== 'idle' ? 'rgba(239,68,68,0.3)' : 'var(--border-active)'}`,
                    color: voice.voiceStatus !== 'idle' ? 'var(--error)' : 'var(--accent-cyan)',
                  }}
                >
                  <Mic size={14} />
                  {voice.voiceStatus !== 'idle' ? 'Stop Voice' : 'Test Voice'}
                </button>
                <span className="text-xs-custom" style={{ color: 'var(--text-muted)' }}>
                  {voice.voiceStatus === 'idle' ? 'Click to start talking' : voice.voiceStatus === 'listening' ? 'Listening...' : voice.voiceStatus === 'processing' ? 'Thinking...' : 'Speaking...'}
                </span>
              </div>

              {/* CORS Warning */}
              <div
                className="p-3 rounded-lg flex items-start gap-2"
                style={{
                  backgroundColor: 'rgba(245,158,11,0.05)',
                  border: '1px solid rgba(245,158,11,0.15)',
                }}
              >
                <AlertTriangle size={14} style={{ color: 'var(--warning)', flexShrink: 0, marginTop: '1px' }} />
                <div className="text-xs-custom" style={{ color: 'var(--warning)', lineHeight: '1.6' }}>
                  <strong>CORS Notice:</strong> Direct API calls from the browser may be blocked.
                  <br />
                  Solutions: (1) Install &quot;CORS Unblock&quot; browser extension
                  (2) Use a proxy: <code style={{ background: 'rgba(255,255,255,0.05)', padding: '1px 4px', borderRadius: '3px' }}>https://corsproxy.io/?https://api.moonshot.cn</code>
                  (3) Use the text input mode instead of voice
                </div>
              </div>

              {/* Conversation Preview */}
              {voice.conversation.length > 0 && (
                <>
                  <div style={{ borderTop: '1px solid rgba(255,255,255,0.04)' }} />
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs-custom flex items-center gap-1" style={{ color: 'var(--text-muted)' }}>
                        <MessageSquare size={12} /> Recent Conversation
                      </span>
                      <button
                        onClick={() => voice.clearConversation()}
                        className="text-xs-custom transition-colors"
                        style={{ color: 'var(--text-muted)' }}
                        onMouseEnter={(e) => (e.currentTarget.style.color = 'var(--error)')}
                        onMouseLeave={(e) => (e.currentTarget.style.color = 'var(--text-muted)')}
                      >
                        Clear
                      </button>
                    </div>
                    <div className="space-y-1.5 max-h-32 overflow-y-auto rounded-lg p-2" style={{ backgroundColor: '#0A0A0A' }}>
                      {voice.conversation.slice(-6).map((msg, i) => (
                        <div key={i} className="text-xs-custom">
                          <span style={{ color: msg.role === 'user' ? 'var(--accent-cyan)' : 'var(--accent-blue)', fontWeight: 600 }}>
                            {msg.role === 'user' ? 'You' : 'AXE'}:
                          </span>{' '}
                          <span style={{ color: 'var(--text-secondary)' }}>{msg.text}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </WidgetCard>
        </motion.div>

        {/* Other Settings */}
        {settingsGroups.map((group, i) => {
          const Icon = group.icon;
          return (
            <motion.div key={group.title} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: (i + 1) * 0.05 }}>
              <WidgetCard title={group.title} headerAction={<Icon size={16} style={{ color: 'var(--text-muted)' }} />}>
                <div className="space-y-2">
                  {group.items.map((item) => (
                    <div key={item.label} className="flex items-center justify-between py-1">
                      <span className="text-small" style={{ color: 'var(--text-secondary)' }}>{item.label}</span>
                      <span className="text-xs-custom font-medium" style={{ color: 'var(--text-primary)' }}>
                        {item.value === 'Enabled' || item.value === 'Connected' ? (
                          <StatusBadge variant="online" label={item.value} size="sm" />
                        ) : item.value === 'Disabled' || item.value === 'Off' ? (
                          <StatusBadge variant="standby" label={item.value} size="sm" />
                        ) : (
                          <span className="font-mono-data">{item.value}</span>
                        )}
                      </span>
                    </div>
                  ))}
                </div>
              </WidgetCard>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
