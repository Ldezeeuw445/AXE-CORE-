import { motion } from 'framer-motion';
import { activeTasks } from '@/lib/mockData';
import { WidgetCard } from '@/components/widgets/WidgetCard';
import { StatusBadge } from '@/components/widgets/StatusBadge';

export default function Tasks() {
  return (
    <motion.div
      className="p-6 h-full overflow-y-auto"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
    >
      <h1 className="text-page-title font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>
        Task Management
      </h1>
      <div className="grid gap-3 max-w-2xl">
        {activeTasks.map((task) => (
          <WidgetCard key={task.id} title="">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={task.completed}
                readOnly
                className="rounded"
                style={{ accentColor: 'var(--accent-cyan)' }}
              />
              <div className="flex-1">
                <span
                  className="text-body block"
                  style={{
                    color: task.completed ? 'var(--text-muted)' : 'var(--text-primary)',
                    textDecoration: task.completed ? 'line-through' : 'none',
                  }}
                >
                  {task.title}
                </span>
                <div className="flex items-center gap-2 mt-1">
                  <div
                    className="h-1.5 rounded-full overflow-hidden flex-1"
                    style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}
                  >
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${task.progress}%`,
                        backgroundColor: task.completed ? 'var(--success)' : 'var(--accent-cyan)',
                      }}
                    />
                  </div>
                  <span className="text-xs-custom font-mono-data" style={{ color: 'var(--text-muted)' }}>
                    {task.progress}%
                  </span>
                </div>
              </div>
              <StatusBadge
                variant={task.completed ? 'online' : task.progress > 0 ? 'active' : 'standby'}
                size="sm"
              />
            </div>
          </WidgetCard>
        ))}
      </div>
    </motion.div>
  );
}
