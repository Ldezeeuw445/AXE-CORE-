import { motion } from 'framer-motion';
import { HolographicSphere } from '@/components/axe-core/HolographicSphere';
import { WidgetCard } from '@/components/widgets/WidgetCard';

export default function AICore() {
  return (
    <motion.div
      className="p-6 h-full overflow-y-auto"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
    >
      <div className="max-w-4xl mx-auto space-y-6">
        <div style={{ minHeight: '500px' }}>
          <WidgetCard title="AXE AI CORE" className="h-full">
            <div style={{ minHeight: '420px' }}>
              <HolographicSphere />
            </div>
          </WidgetCard>
        </div>
        <div
          className="p-8 rounded-xl text-center"
          style={{
            backgroundColor: 'var(--bg-surface)',
            border: '1px solid var(--border-subtle)',
          }}
        >
          <h2
            className="text-page-title font-semibold mb-2"
            style={{ color: 'var(--text-primary)' }}
          >
            AI Core Module
          </h2>
          <p className="text-body" style={{ color: 'var(--text-secondary)' }}>
            Central intelligence hub — memory insights, processing status, and connected models.
            Full implementation coming in the next phase.
          </p>
        </div>
      </div>
    </motion.div>
  );
}
