import { motion } from 'framer-motion';
import {
  Circle, Brain, Mic, Bot, Plug, Zap, Activity,
  Check, ChevronRight, Terminal, Plus, Calendar, Play, FilePlus,
} from 'lucide-react';
import { useNavigate } from 'react-router';
import { HolographicSphere } from '@/components/axe-core/HolographicSphere';
import { WidgetCard } from '@/components/widgets/WidgetCard';
import { StatusBadge } from '@/components/widgets/StatusBadge';
import { ProgressRing } from '@/components/widgets/ProgressRing';
import { AgentCard } from '@/components/widgets/AgentCard';
import { MetricDisplay } from '@/components/widgets/MetricDisplay';
import { LiveIndicator } from '@/components/shared/LiveIndicator';
import {
  activeAgents, systemMetrics, llmProviders,
  timelineEvents, memoryStats, connectedModels, recentActivities,
  aiCoreStatus, intelligenceFeed,
} from '@/lib/mockData';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.04, delayChildren: 0.2 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] },
  },
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const statusIcons: Record<string, React.ComponentType<any>> = {
  circle: Circle,
  brain: Brain,
  mic: Mic,
  bot: Bot,
  plug: Plug,
  zap: Zap,
};

/* ── left-panel icon map for quick commands ── */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const quickCmdIcons: Record<string, React.ComponentType<any>> = {
  plus: Plus,
  calendar: Calendar,
  mic: Mic,
  play: Play,
  terminal: Terminal,
  'file-plus': FilePlus,
};

/* ── feed type colours ── */
const feedTypeColors: Record<string, string> = {
  MEETING: 'var(--accent-blue)',
  WARN: 'var(--warning)',
  TIP: 'var(--accent-cyan)',
  LIVE: 'var(--success)',
  FOCUS: 'var(--accent-blue)',
};

const feedBadgeVariant = (type: string): 'online' | 'active' | 'warning' => {
  if (type === 'WARN') return 'warning';
  if (type === 'LIVE') return 'active';
  return 'online';
};

export default function Home() {
  const navigate = useNavigate();

  return (
    <motion.div
      className="flex flex-col gap-3 p-3 h-full overflow-y-auto"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      {/* ═══════════════════════════════════════════
          MAIN 3-COLUMN ROW
         ═══════════════════════════════════════════ */}
      <div className="flex gap-3 flex-1 min-h-0">

        {/* ─── LEFT PANEL (280px) ─── */}
        <div className="flex flex-col gap-3 w-[280px] flex-shrink-0 overflow-y-auto">

          {/* AI Core Overview */}
          <motion.div variants={itemVariants}>
            <WidgetCard
              title="AI CORE OVERVIEW"
              headerAction={
                <button style={{ color: 'var(--text-muted)' }}>
                  <Terminal size={14} />
                </button>
              }
            >
              <div className="space-y-2">
                {aiCoreStatus.map((item, i) => {
                  const Icon = statusIcons[item.icon] || Circle;
                  return (
                    <motion.div
                      key={item.label}
                      className="flex items-center justify-between"
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.4 + i * 0.06, duration: 0.3 }}
                    >
                      <div className="flex items-center gap-2">
                        <Icon size={14} style={{ color: 'var(--accent-cyan)' }} />
                        <span className="text-small" style={{ color: 'var(--text-secondary)' }}>
                          {item.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className="rounded-full"
                          style={{
                            width: '5px',
                            height: '5px',
                            backgroundColor:
                              item.status === 'online'
                                ? 'var(--success)'
                                : 'var(--accent-cyan)',
                          }}
                        />
                        <span className="text-xs-custom" style={{ color: 'var(--text-secondary)' }}>
                          {item.value}
                        </span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
              <button
                className="text-small mt-2 flex items-center gap-1 transition-colors duration-fast"
                style={{ color: 'var(--accent-blue)' }}
                onClick={() => navigate('/ai-core')}
                onMouseEnter={(e) => { e.currentTarget.style.textDecoration = 'underline'; }}
                onMouseLeave={(e) => { e.currentTarget.style.textDecoration = 'none'; }}
              >
                View Full AI Core <ChevronRight size={14} />
              </button>
            </WidgetCard>
          </motion.div>

          {/* System Monitor */}
          <motion.div variants={itemVariants}>
            <WidgetCard title="SYSTEM MONITOR">
              <div className="flex justify-around py-1">
                <ProgressRing value={systemMetrics.cpu} label="CPU" size="sm" />
                <ProgressRing value={systemMetrics.ram} label="RAM" size="sm" />
                <ProgressRing value={systemMetrics.disk} label="Disk" size="sm" />
              </div>
              <div className="grid grid-cols-3 gap-1 mt-2">
                <div className="text-center">
                  <span className="text-xs-custom block" style={{ color: 'var(--text-secondary)' }}>
                    {systemMetrics.cpu}%
                  </span>
                  <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                    Load: {systemMetrics.load}
                  </span>
                </div>
                <div className="text-center">
                  <span className="text-xs-custom block" style={{ color: 'var(--text-secondary)' }}>
                    {systemMetrics.ramUsed}/{systemMetrics.ramTotal}GB
                  </span>
                  <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                    Proc: {systemMetrics.processes}
                  </span>
                </div>
                <div className="text-center">
                  <span className="text-xs-custom block" style={{ color: 'var(--text-secondary)' }}>
                    {systemMetrics.disk}%
                  </span>
                  <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                    Disk U
                  </span>
                </div>
              </div>
            </WidgetCard>
          </motion.div>

          {/* Active Agents (compact strip) */}
          <motion.div variants={itemVariants}>
            <WidgetCard
              title="ACTIVE AGENTS"
              headerAction={
                <button
                  className="text-xs-custom flex items-center gap-1"
                  style={{ color: 'var(--accent-blue)' }}
                  onClick={() => navigate('/agents')}
                >
                  All <ChevronRight size={12} />
                </button>
              }
            >
              <div className="flex gap-2 overflow-x-auto pb-1">
                {activeAgents.slice(0, 4).map((agent, i) => (
                  <motion.div
                    key={agent.id}
                    initial={{ opacity: 0, y: 12, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{
                      delay: 0.5 + i * 0.07,
                      duration: 0.3,
                      ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
                    }}
                  >
                    <AgentCard agent={agent} compact />
                  </motion.div>
                ))}
              </div>
            </WidgetCard>
          </motion.div>

          {/* Quick Commands */}
          <motion.div variants={itemVariants}>
            <WidgetCard title="QUICK COMMANDS">
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { icon: 'plus', label: 'New Task' },
                  { icon: 'calendar', label: 'Calendar' },
                  { icon: 'mic', label: 'Voice' },
                  { icon: 'play', label: 'Workflow' },
                  { icon: 'terminal', label: 'Command' },
                  { icon: 'file-plus', label: 'Note' },
                ].map((cmd, i) => {
                  const CmdIcon = quickCmdIcons[cmd.icon] || Plus;
                  return (
                    <motion.button
                      key={cmd.label}
                      className="flex flex-col items-center gap-1 p-2 rounded-lg transition-all duration-fast"
                      style={{
                        backgroundColor: 'var(--bg-surface)',
                        border: '1px solid var(--border-subtle)',
                      }}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.55 + i * 0.05, duration: 0.25 }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.backgroundColor = 'var(--bg-hover)';
                        e.currentTarget.style.borderColor = 'var(--border-active)';
                        e.currentTarget.style.transform = 'translateY(-1px)';
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.backgroundColor = 'var(--bg-surface)';
                        e.currentTarget.style.borderColor = 'var(--border-subtle)';
                        e.currentTarget.style.transform = 'translateY(0)';
                      }}
                    >
                      <CmdIcon size={14} style={{ color: 'var(--text-secondary)' }} />
                      <span className="text-[10px] text-center" style={{ color: 'var(--text-secondary)' }}>
                        {cmd.label}
                      </span>
                    </motion.button>
                  );
                })}
              </div>
            </WidgetCard>
          </motion.div>
        </div>

        {/* ─── CENTER PANEL — 3D HOLOGRAPHIC CORE ─── */}
        <motion.div
          variants={itemVariants}
          className="flex-1 flex flex-col relative min-h-0"
        >
          {/* Center panel — pure black */}
          <div
            className="relative flex-1 rounded-2xl overflow-hidden flex flex-col"
            style={{
              backgroundColor: '#000000',
              border: '1px solid rgba(255, 255, 255, 0.04)',
            }}
          >

            {/* Top-left live indicator */}
            <div className="absolute top-4 left-4 flex items-center gap-2 z-10">
              <LiveIndicator size={6} />
              <span className="text-xs-custom font-mono-data" style={{ color: 'var(--accent-cyan)' }}>
                CORE ACTIVE
              </span>
            </div>

            {/* Top-right version */}
            <div
              className="absolute top-4 right-4 text-xs-custom font-mono-data z-10"
              style={{ color: 'var(--text-muted)' }}
            >
              v3.0.0
            </div>

            {/* 3D Holographic AXE Core — fills the panel */}
            <div className="flex-1 relative" style={{ minHeight: 0 }}>
              <HolographicSphere />
            </div>
          </div>
        </motion.div>

        {/* ─── RIGHT PANEL (320px) ─── */}
        <div className="flex flex-col gap-3 w-[320px] flex-shrink-0 overflow-y-auto">

          {/* Live Intelligence Feed */}
          <motion.div variants={itemVariants}>
            <WidgetCard
              title="LIVE INTELLIGENCE FEED"
              headerAction={
                <button
                  className="text-xs-custom flex items-center gap-1"
                  style={{ color: 'var(--accent-blue)' }}
                >
                  View All <ChevronRight size={12} />
                </button>
              }
            >
              <div className="space-y-1">
                {intelligenceFeed.slice(0, 6).map((item, i) => (
                  <motion.div
                    key={item.id}
                    className="flex items-start gap-2 p-1.5 rounded-lg transition-colors duration-fast cursor-pointer"
                    initial={{ opacity: 0, x: 12 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.45 + i * 0.07, duration: 0.3 }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = 'var(--bg-hover)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    <span
                      className="rounded-full mt-1 flex-shrink-0"
                      style={{
                        width: '5px',
                        height: '5px',
                        backgroundColor: feedTypeColors[item.type] || 'var(--accent-cyan)',
                      }}
                    />
                    <div className="flex-1 min-w-0">
                      <span className="text-small block truncate">{item.title}</span>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                          {item.timestamp}
                        </span>
                        <StatusBadge variant={feedBadgeVariant(item.type)} label={item.type} size="sm" />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </WidgetCard>
          </motion.div>

          {/* Quick Actions */}
          <motion.div variants={itemVariants}>
            <WidgetCard title="QUICK ACTIONS">
              <div className="grid grid-cols-2 gap-2">
                {[
                  { icon: <Plus size={16} />, label: 'Start New Task', color: 'var(--accent-cyan)' },
                  { icon: <Calendar size={16} />, label: 'Open Calendar', color: 'var(--accent-blue)' },
                  { icon: <Mic size={16} />, label: 'Start Voice Chat', color: 'var(--success)' },
                  { icon: <Play size={16} />, label: 'Run Workflow', color: 'var(--warning)' },
                  { icon: <Terminal size={16} />, label: 'Open Command', color: 'var(--accent-ice)' },
                  { icon: <FilePlus size={16} />, label: 'Create Note', color: 'var(--accent-cyan)' },
                ].map((action, i) => (
                  <motion.button
                    key={action.label}
                    className="flex items-center gap-2 p-2.5 rounded-lg transition-all duration-fast text-left"
                    style={{
                      backgroundColor: 'var(--bg-surface)',
                      border: '1px solid var(--border-subtle)',
                    }}
                    initial={{ opacity: 0, scale: 0.92 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.5 + i * 0.05, duration: 0.25 }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = 'var(--bg-hover)';
                      e.currentTarget.style.borderColor = 'var(--border-active)';
                      e.currentTarget.style.transform = 'translateY(-1px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = 'var(--bg-surface)';
                      e.currentTarget.style.borderColor = 'var(--border-subtle)';
                      e.currentTarget.style.transform = 'translateY(0)';
                    }}
                  >
                    <span style={{ color: action.color }}>{action.icon}</span>
                    <span className="text-xs-custom" style={{ color: 'var(--text-secondary)' }}>
                      {action.label}
                    </span>
                  </motion.button>
                ))}
              </div>
            </WidgetCard>
          </motion.div>

          {/* System Health */}
          <motion.div variants={itemVariants}>
            <WidgetCard
              title="SYSTEM HEALTH"
              headerAction={
                <div className="flex items-center gap-1.5">
                  <Activity size={12} style={{ color: 'var(--success)' }} />
                  <span className="text-[10px]" style={{ color: 'var(--success)' }}>
                    Healthy
                  </span>
                </div>
              }
            >
              <div className="space-y-2">
                {[
                  { label: 'CPU Load', value: `${systemMetrics.cpu}%`, color: 'var(--accent-cyan)', width: `${systemMetrics.cpu}%` },
                  { label: 'Memory', value: `${systemMetrics.ram}%`, color: 'var(--accent-blue)', width: `${systemMetrics.ram}%` },
                  { label: 'Disk', value: `${systemMetrics.disk}%`, color: 'var(--success)', width: `${systemMetrics.disk}%` },
                  { label: 'Network', value: '12ms', color: 'var(--accent-ice)', width: '15%' },
                ].map((metric, i) => (
                  <motion.div
                    key={metric.label}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.55 + i * 0.06 }}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs-custom" style={{ color: 'var(--text-secondary)' }}>
                        {metric.label}
                      </span>
                      <span className="text-xs-custom font-mono-data" style={{ color: 'var(--text-primary)' }}>
                        {metric.value}
                      </span>
                    </div>
                    <div
                      className="h-1 rounded-full overflow-hidden"
                      style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}
                    >
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: metric.color }}
                        initial={{ width: 0 }}
                        animate={{ width: metric.width }}
                        transition={{ delay: 0.6 + i * 0.06, duration: 0.6, ease: 'easeOut' }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </WidgetCard>
          </motion.div>

          {/* Connected Models */}
          <motion.div variants={itemVariants}>
            <WidgetCard
              title="CONNECTED MODELS"
              headerAction={
                <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>
                  {connectedModels.length} models
                </span>
              }
            >
              <div className="space-y-2">
                {connectedModels.map((model, i) => (
                  <motion.div
                    key={model.name}
                    className="flex items-center gap-2"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.6 + i * 0.1, duration: 0.3 }}
                  >
                    <span
                      className="text-xs-custom w-[100px] truncate"
                      style={{ color: 'var(--text-primary)' }}
                    >
                      {model.name}
                    </span>
                    <div
                      className="flex-1 h-1 rounded-full overflow-hidden"
                      style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}
                    >
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: 'var(--accent-cyan)' }}
                        initial={{ width: 0 }}
                        animate={{ width: `${model.usage}%` }}
                        transition={{ delay: 0.7 + i * 0.1, duration: 0.6, ease: 'easeOut' }}
                      />
                    </div>
                    <span
                      className="text-[10px] font-mono-data w-[28px] text-right"
                      style={{ color: 'var(--text-secondary)' }}
                    >
                      {model.usage}%
                    </span>
                  </motion.div>
                ))}
              </div>
              <div className="mt-2 pt-2 space-y-1" style={{ borderTop: '1px solid var(--border-subtle)' }}>
                <span className="text-xs-custom block" style={{ color: 'var(--text-secondary)' }}>
                  Tokens today: <span className="font-mono-data" style={{ color: 'var(--text-primary)' }}>47,382</span>
                </span>
                <span className="text-xs-custom block" style={{ color: 'var(--text-secondary)' }}>
                  Avg latency: <span className="font-mono-data" style={{ color: 'var(--text-primary)' }}>42ms</span>
                </span>
              </div>
            </WidgetCard>
          </motion.div>
        </div>
      </div>

      {/* ═══════════════════════════════════════════
          BOTTOM ROW
         ═══════════════════════════════════════════ */}
      <div className="flex gap-3 flex-shrink-0">

        {/* Mission Timeline */}
        <motion.div variants={itemVariants} className="flex-1 min-w-0">
          <WidgetCard
            title="MISSION TIMELINE"
            headerAction={
              <span className="text-xs-custom" style={{ color: 'var(--text-secondary)' }}>
                Today ▼
              </span>
            }
          >
            <div className="relative pl-2 space-y-2">
              {/* Vertical line */}
              <div
                className="absolute left-[26px] top-0 bottom-0"
                style={{
                  width: '1px',
                  backgroundColor: 'var(--border-subtle)',
                }}
              />
              {timelineEvents.map((event, i) => (
                <motion.div
                  key={event.id}
                  className="flex items-start gap-2 relative"
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + i * 0.08, duration: 0.3 }}
                >
                  <span
                    className="font-mono-data text-[10px] w-[28px] text-right flex-shrink-0 pt-0.5"
                    style={{ color: 'var(--text-muted)' }}
                  >
                    {event.time}
                  </span>
                  <div className="relative flex-shrink-0">
                    <span
                      className="block rounded-full"
                      style={{
                        width: '5px',
                        height: '5px',
                        backgroundColor:
                          event.status === 'done'
                            ? 'var(--text-muted)'
                            : event.status === 'in-progress'
                              ? 'var(--accent-cyan)'
                              : 'var(--border-subtle)',
                        marginTop: '5px',
                        boxShadow:
                          event.status === 'in-progress'
                            ? '0 0 6px var(--accent-cyan)'
                            : 'none',
                      }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span
                      className="text-small block truncate"
                      style={{
                        color:
                          event.status === 'done'
                            ? 'var(--text-muted)'
                            : 'var(--text-primary)',
                        textDecoration: event.status === 'done' ? 'line-through' : 'none',
                      }}
                    >
                      {event.title}
                    </span>
                  </div>
                  <span
                    className="text-[10px] flex-shrink-0"
                    style={{
                      color:
                        event.status === 'done'
                          ? 'var(--text-muted)'
                          : event.status === 'in-progress'
                            ? 'var(--accent-cyan)'
                            : 'var(--text-secondary)',
                    }}
                  >
                    {event.status === 'done' && <Check size={11} className="inline" />}
                    {event.relativeTime}
                  </span>
                </motion.div>
              ))}
            </div>
          </WidgetCard>
        </motion.div>

        {/* Memory Insights */}
        <motion.div variants={itemVariants} className="w-[240px] flex-shrink-0">
          <WidgetCard
            title="MEMORY INSIGHTS"
            headerAction={
              <button
                className="text-xs-custom flex items-center gap-1"
                style={{ color: 'var(--accent-blue)' }}
                onClick={() => navigate('/memory')}
              >
                Map <ChevronRight size={12} />
              </button>
            }
          >
            {/* Mini neural graph */}
            <div
              className="relative rounded-lg overflow-hidden cursor-pointer mb-2"
              style={{
                height: '70px',
                backgroundColor: 'var(--bg-base)',
              }}
              onClick={() => navigate('/memory')}
            >
              <svg width="100%" height="100%" viewBox="0 0 200 70">
                <g stroke="rgba(255,255,255,0.05)" strokeWidth="1">
                  <line x1="30" y1="25" x2="70" y2="35" />
                  <line x1="70" y1="35" x2="110" y2="25" />
                  <line x1="70" y1="35" x2="100" y2="50" />
                  <line x1="110" y1="25" x2="150" y2="30" />
                  <line x1="100" y1="50" x2="140" y2="45" />
                  <line x1="150" y1="30" x2="175" y2="18" />
                  <line x1="140" y1="45" x2="175" y2="40" />
                  <line x1="30" y1="25" x2="45" y2="48" />
                  <line x1="45" y1="48" x2="100" y2="50" />
                </g>
                {[
                  { cx: 30, cy: 25, r: 3.5, fill: '#22D3EE' },
                  { cx: 70, cy: 35, r: 4, fill: '#3B82F6' },
                  { cx: 110, cy: 25, r: 3.5, fill: '#A78BFA' },
                  { cx: 100, cy: 50, r: 3, fill: '#22D3EE' },
                  { cx: 150, cy: 30, r: 3.5, fill: '#60A5FA' },
                  { cx: 140, cy: 45, r: 3, fill: '#A78BFA' },
                  { cx: 175, cy: 18, r: 2.5, fill: '#22D3EE' },
                  { cx: 175, cy: 40, r: 3, fill: '#3B82F6' },
                  { cx: 45, cy: 48, r: 3, fill: '#60A5FA' },
                ].map((node, i) => (
                  <circle key={i} {...node} opacity={0.7} />
                ))}
              </svg>
            </div>
            {/* Metrics */}
            <div className="grid grid-cols-2 gap-x-3 gap-y-1">
              <MetricDisplay value={memoryStats.memories.toLocaleString()} label="Memories" />
              <MetricDisplay value={memoryStats.sessions} label="Sessions" />
              <MetricDisplay value={memoryStats.topicTurns.toLocaleString()} label="Topic Turns" />
              <MetricDisplay value={memoryStats.totalChats} label="Total Chats" />
            </div>
          </WidgetCard>
        </motion.div>

        {/* LLM Status */}
        <motion.div variants={itemVariants} className="w-[220px] flex-shrink-0">
          <WidgetCard
            title="LLM STATUS"
            headerAction={
              <span className="text-[10px]" style={{ color: 'var(--text-secondary)' }}>
                {llmProviders.filter((p) => p.status === 'connected').length} Connected
              </span>
            }
          >
            <div className="space-y-1.5">
              {llmProviders.slice(0, 5).map((provider, i) => (
                <motion.div
                  key={provider.id}
                  className="flex items-center justify-between py-1"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 + i * 0.06, duration: 0.25 }}
                >
                  <div className="flex items-center gap-1.5">
                    <span
                      className="rounded-full"
                      style={{
                        width: '5px',
                        height: '5px',
                        backgroundColor:
                          provider.status === 'connected'
                            ? 'var(--success)'
                            : provider.status === 'standby'
                              ? 'var(--text-muted)'
                              : 'var(--warning)',
                      }}
                    />
                    <span className="text-xs-custom" style={{ color: 'var(--text-primary)' }}>
                      {provider.name}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono-data" style={{ color: 'var(--text-muted)' }}>
                    {provider.latency ? `${provider.latency}ms` : '--'}
                  </span>
                </motion.div>
              ))}
            </div>
          </WidgetCard>
        </motion.div>

        {/* Recent Activity */}
        <motion.div variants={itemVariants} className="w-[280px] flex-shrink-0">
          <WidgetCard title="RECENT ACTIVITY">
            <div className="space-y-1.5">
              {recentActivities.slice(0, 4).map((activity, i) => (
                <motion.div
                  key={activity.id}
                  className="flex items-start gap-2 p-1.5 rounded-lg transition-colors duration-fast cursor-pointer"
                  initial={{ opacity: 0, x: -8 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.55 + i * 0.07, duration: 0.3 }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'var(--bg-hover)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  <div
                    className="rounded-full flex items-center justify-center flex-shrink-0 text-[10px] font-bold"
                    style={{
                      width: '24px',
                      height: '24px',
                      backgroundColor: 'var(--bg-hover)',
                      color: 'var(--accent-cyan)',
                    }}
                  >
                    {activity.agent[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-xs-custom font-medium block" style={{ color: 'var(--text-primary)' }}>
                      {activity.agent}
                    </span>
                    <span className="text-[10px] block truncate" style={{ color: 'var(--text-secondary)' }}>
                      {activity.description}
                    </span>
                  </div>
                  <span className="text-[10px] flex-shrink-0" style={{ color: 'var(--text-muted)' }}>
                    {activity.timestamp}
                  </span>
                </motion.div>
              ))}
            </div>
          </WidgetCard>
        </motion.div>
      </div>
    </motion.div>
  );
}
