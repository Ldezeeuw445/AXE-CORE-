import { motion } from 'framer-motion';
import { WidgetCard } from '@/components/widgets/WidgetCard';
import { StatusBadge } from '@/components/widgets/StatusBadge';
import { MetricDisplay } from '@/components/widgets/MetricDisplay';

const mcpServers = [
  { name: 'filesystem', status: 'online' as const, latency: 12, version: '1.2.0' },
  { name: 'browser', status: 'online' as const, latency: 45, version: '2.0.1' },
  { name: 'github', status: 'online' as const, latency: 89, version: '1.5.0' },
  { name: 'slack', status: 'standby' as const, latency: null, version: '1.0.3' },
  { name: 'notion', status: 'online' as const, latency: 67, version: '1.1.0' },
  { name: 'linear', status: 'online' as const, latency: 34, version: '1.3.0' },
  { name: 'discord', status: 'standby' as const, latency: null, version: '0.9.0' },
  { name: 'postgres', status: 'online' as const, latency: 8, version: '1.4.0' },
];

export default function MCPCenter() {
  return (
    <motion.div
      className="p-6 h-full overflow-y-auto"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
    >
      <h1 className="text-page-title font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>
        MCP Center
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <WidgetCard title="Connected">
          <MetricDisplay value={mcpServers.filter((s) => s.status === 'online').length.toString()} label="of 8 servers online" />
        </WidgetCard>
        <WidgetCard title="Avg Latency">
          <MetricDisplay value="43ms" label="Across all active MCPs" />
        </WidgetCard>
        <WidgetCard title="Tool Calls">
          <MetricDisplay value="1,247" label="Today" delta={12} />
        </WidgetCard>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {mcpServers.map((server, i) => (
          <motion.div
            key={server.name}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
          >
            <WidgetCard title="">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div
                    className="rounded-lg flex items-center justify-center"
                    style={{
                      width: '36px',
                      height: '36px',
                      backgroundColor: 'var(--bg-hover)',
                      color: 'var(--accent-cyan)',
                      fontSize: '10px',
                      fontWeight: 600,
                      fontFamily: 'JetBrains Mono, monospace',
                    }}
                  >
                    {server.name.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <span className="text-body font-medium block" style={{ color: 'var(--text-primary)' }}>
                      {server.name}
                    </span>
                    <span className="text-xs-custom" style={{ color: 'var(--text-muted)' }}>
                      v{server.version}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  {server.latency && (
                    <span className="text-xs-custom font-mono-data" style={{ color: 'var(--text-muted)' }}>
                      {server.latency}ms
                    </span>
                  )}
                  <StatusBadge variant={server.status} size="sm" />
                </div>
              </div>
            </WidgetCard>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
