import { motion } from 'framer-motion';
import { WidgetCard } from '@/components/widgets/WidgetCard';
import { MetricDisplay } from '@/components/widgets/MetricDisplay';
import { FileText } from 'lucide-react';

const docs = [
  { title: 'AXE Architecture Overview', category: 'Architecture', updated: '2d ago', size: '24KB' },
  { title: 'Agent SDK Documentation', category: 'Developer', updated: '5d ago', size: '156KB' },
  { title: 'Voice Pipeline Spec', category: 'Engineering', updated: '1w ago', size: '42KB' },
  { title: 'Trading Strategy Guide', category: 'Trading', updated: '2w ago', size: '89KB' },
  { title: 'Security Best Practices', category: 'Security', updated: '3w ago', size: '33KB' },
];

const tags = ['AI', 'Trading', 'Security', 'DevOps', 'Design', 'Voice', 'Memory', 'Agents', 'API', 'UI/UX'];

export default function KnowledgeBase() {
  return (
    <motion.div
      className="p-6 h-full overflow-y-auto"
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
    >
      <h1 className="text-page-title font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>
        Knowledge Base
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <WidgetCard title="Documents">
          <MetricDisplay value="247" label="Total documents" />
        </WidgetCard>
        <WidgetCard title="Categories">
          <MetricDisplay value="18" label="Knowledge categories" />
        </WidgetCard>
        <WidgetCard title="Last Updated">
          <MetricDisplay value="2h ago" label="By Memory Agent" />
        </WidgetCard>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="md:col-span-2 space-y-2">
          {docs.map((doc, i) => (
            <motion.div
              key={doc.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <WidgetCard title="">
                <div className="flex items-center gap-3">
                  <FileText size={18} style={{ color: 'var(--accent-cyan)' }} />
                  <div className="flex-1">
                    <span className="text-body font-medium block" style={{ color: 'var(--text-primary)' }}>
                      {doc.title}
                    </span>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-xs-custom" style={{ color: 'var(--text-muted)' }}>{doc.category}</span>
                      <span style={{ color: 'var(--text-muted)' }}>·</span>
                      <span className="text-xs-custom" style={{ color: 'var(--text-muted)' }}>{doc.updated}</span>
                      <span className="text-xs-custom font-mono-data" style={{ color: 'var(--text-muted)' }}>{doc.size}</span>
                    </div>
                  </div>
                </div>
              </WidgetCard>
            </motion.div>
          ))}
        </div>
        <WidgetCard title="Tags">
          <div className="flex flex-wrap gap-1.5">
            {tags.map((tag) => (
              <span
                key={tag}
                className="text-xs-custom px-2 py-1 rounded-md cursor-pointer transition-colors duration-fast"
                style={{
                  backgroundColor: 'var(--bg-hover)',
                  color: 'var(--text-secondary)',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--bg-active)';
                  e.currentTarget.style.color = 'var(--accent-cyan)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = 'var(--bg-hover)';
                  e.currentTarget.style.color = 'var(--text-secondary)';
                }}
              >
                {tag}
              </span>
            ))}
          </div>
        </WidgetCard>
      </div>
    </motion.div>
  );
}
