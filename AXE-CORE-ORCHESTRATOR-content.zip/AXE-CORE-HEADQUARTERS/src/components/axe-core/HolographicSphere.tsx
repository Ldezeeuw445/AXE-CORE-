import { useEffect, useRef } from 'react';

/*
 * Realistic HUD Ring System — inspired by JARVIS / Iron Man interfaces
 * Canvas 2D, 60fps, pure black background matching the app
 */

export function HolographicSphere() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rafRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let w = 0;
    let h = 0;
    let cx = 0;
    let cy = 0;
    let t = 0;

    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const rect = canvas!.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas!.width = w * dpr;
      canvas!.height = h * dpr;
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
      cx = w / 2;
      cy = h / 2;
    }

    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    // Colors
    const C_RING = 'rgba(100, 200, 255, 0.35)';
    const C_RING_DIM = 'rgba(100, 200, 255, 0.12)';
    const C_GLOW = 'rgba(100, 200, 255, 0.08)';
    const C_TICK = 'rgba(180, 230, 255, 0.7)';
    const C_TICK_MAJOR = 'rgba(200, 240, 255, 0.9)';
    const C_SEGMENT = 'rgba(80, 180, 240, 0.6)';
    const C_SEGMENT_GLOW = 'rgba(100, 200, 255, 0.25)';
    void C_GLOW; // C_GLOW is used via reference

    function drawRing(radius: number, rotation: number, segments: number, segLen: number, segGap: number, glow: boolean) {
      if (!ctx) return;
      const step = (Math.PI * 2) / segments;
      for (let i = 0; i < segments; i++) {
        const angle = i * step + rotation;
        const active = Math.sin(angle * 3 + t * 0.02) > 0.3;
        const brightness = active ? C_SEGMENT : C_RING_DIM;

        ctx.beginPath();
        ctx.arc(cx, cy, radius, angle + segGap / 2, angle + step - segGap / 2);
        ctx.strokeStyle = brightness;
        ctx.lineWidth = segLen;
        ctx.stroke();

        if (glow && active) {
          ctx.beginPath();
          ctx.arc(cx, cy, radius, angle + segGap / 2, angle + step - segGap / 2);
          ctx.strokeStyle = C_SEGMENT_GLOW;
          ctx.lineWidth = segLen + 4;
          ctx.stroke();
        }
      }
    }

    function drawTicks(radius: number, rotation: number, count: number, majorInterval: number) {
      if (!ctx) return;
      const step = (Math.PI * 2) / count;
      for (let i = 0; i < count; i++) {
        const angle = i * step + rotation;
        const isMajor = i % majorInterval === 0;
        const innerR = radius - (isMajor ? 10 : 5);
        const x1 = cx + Math.cos(angle) * innerR;
        const y1 = cy + Math.sin(angle) * innerR;
        const x2 = cx + Math.cos(angle) * radius;
        const y2 = cy + Math.sin(angle) * radius;

        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.strokeStyle = isMajor ? C_TICK_MAJOR : C_TICK;
        ctx.lineWidth = isMajor ? 1.5 : 0.8;
        ctx.stroke();
      }
    }

    function drawDots(radius: number, rotation: number, count: number) {
      if (!ctx) return;
      const step = (Math.PI * 2) / count;
      for (let i = 0; i < count; i++) {
        const angle = i * step + rotation;
        const pulse = 0.5 + 0.5 * Math.sin(t * 0.03 + i * 0.5);
        ctx.beginPath();
        ctx.arc(cx + Math.cos(angle) * radius, cy + Math.sin(angle) * radius, 2.5 * pulse, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(80, 180, 240, ${0.3 * pulse})`;
        ctx.fill();
      }
    }

    function drawHexagon(radius: number) {
      if (!ctx) return;
      const sides = 6;
      const step = (Math.PI * 2) / sides;
      ctx.beginPath();
      for (let i = 0; i <= sides; i++) {
        const a = i * step - Math.PI / 6;
        const x = cx + Math.cos(a) * radius;
        const y = cy + Math.sin(a) * radius;
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
      }
      ctx.strokeStyle = C_RING;
      ctx.lineWidth = 0.5;
      ctx.stroke();
    }

    function drawHexPattern(radius: number) {
      if (!ctx) return;
      const hexSize = 12;
      const hexW = hexSize * 2;
      const hexH = Math.sqrt(3) * hexSize;
      const cols = Math.ceil(radius * 2 / hexW) + 2;
      const rows = Math.ceil(radius * 2 / hexH) + 2;

      for (let row = -rows; row <= rows; row++) {
        for (let col = -cols; col <= cols; col++) {
          const x = cx + col * hexW + (row % 2) * hexW * 0.5;
          const y = cy + row * hexH * 0.75;
          const dist = Math.sqrt((x - cx) ** 2 + (y - cy) ** 2);
          if (dist > radius - 5) continue;

          const alpha = Math.max(0, 0.06 * (1 - dist / radius));
          ctx.beginPath();
          for (let i = 0; i < 6; i++) {
            const a = (Math.PI / 3) * i - Math.PI / 6;
            const hx = x + hexSize * 0.5 * Math.cos(a);
            const hy = y + hexSize * 0.5 * Math.sin(a);
            i === 0 ? ctx.moveTo(hx, hy) : ctx.lineTo(hx, hy);
          }
          ctx.closePath();
          ctx.strokeStyle = `rgba(60, 160, 220, ${alpha})`;
          ctx.lineWidth = 0.4;
          ctx.stroke();
        }
      }
    }

    function drawOrbitingArcs(radius: number, t: number) {
      if (!ctx) return;
      // Two counter-rotating arcs
      for (let i = 0; i < 3; i++) {
        const startAngle = t * 0.01 * (i % 2 === 0 ? 1 : -1) + i * (Math.PI * 2 / 3);
        const arcLen = Math.PI * 0.4;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, startAngle, startAngle + arcLen);
        ctx.strokeStyle = `rgba(120, 210, 255, ${0.5 - i * 0.15})`;
        ctx.lineWidth = 2;
        ctx.stroke();

        // Glow
        ctx.beginPath();
        ctx.arc(cx, cy, radius, startAngle, startAngle + arcLen);
        ctx.strokeStyle = `rgba(120, 210, 255, ${0.12 - i * 0.04})`;
        ctx.lineWidth = 8;
        ctx.stroke();
      }
    }

    function drawScanLine(radius: number, t: number) {
      if (!ctx) return;
      const scanAngle = t * 0.008;
      const sx = cx + Math.cos(scanAngle) * radius * 0.3;
      const sy = cy + Math.sin(scanAngle) * radius * 0.3;
      const ex = cx + Math.cos(scanAngle) * radius;
      const ey = cy + Math.sin(scanAngle) * radius;

      // Main line
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(ex, ey);
      ctx.strokeStyle = 'rgba(140, 220, 255, 0.15)';
      ctx.lineWidth = 20;
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(ex, ey);
      ctx.strokeStyle = 'rgba(180, 240, 255, 0.4)';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    function draw() {
      if (!ctx) return;
      t++;

      // CLEAR — pure black, NO blue tint
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, w, h);

      const R = Math.min(w, h) * 0.42;

      // Outer subtle glow ring
      const grad = ctx.createRadialGradient(cx, cy, R * 0.8, cx, cy, R * 1.4);
      grad.addColorStop(0, 'rgba(100, 200, 255, 0.0)');
      grad.addColorStop(0.5, C_GLOW);
      grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, w, h);

      // Hex pattern background
      drawHexPattern(R * 0.85);

      // Ring 1: Outer dots
      drawDots(R * 1.15, t * 0.003, 40);

      // Ring 2: Outer segmented ring (counter-clockwise)
      drawRing(R * 1.0, -t * 0.005, 48, 3, 0.05, true);

      // Ring 3: Tick marks
      drawTicks(R * 0.88, 0, 72, 6);

      // Ring 4: Middle segmented ring (clockwise)
      drawRing(R * 0.82, t * 0.008, 36, 4, 0.04, true);

      // Ring 5: Inner tick marks
      drawTicks(R * 0.72, t * 0.002, 48, 8);

      // Ring 6: Inner segmented ring
      drawRing(R * 0.66, -t * 0.012, 24, 5, 0.06, true);

      // Hexagon overlay
      drawHexagon(R * 0.55);
      drawHexagon(R * 0.50);

      // Orbiting arcs
      drawOrbitingArcs(R * 0.92, t);

      // Scan line
      drawScanLine(R * 0.95, t);

      // Inner dark circle (AXE text area)
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.45, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fill();
      ctx.strokeStyle = C_RING;
      ctx.lineWidth = 0.5;
      ctx.stroke();

      // Center text
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // AXE title
      ctx.font = `600 ${Math.max(18, R * 0.18)}px Inter, system-ui, sans-serif`;
      ctx.fillStyle = '#FFFFFF';
      ctx.fillText('AXE', cx, cy - R * 0.06);

      // AI CORE
      ctx.font = `400 ${Math.max(10, R * 0.07)}px Inter, system-ui, sans-serif`;
      ctx.fillStyle = 'rgba(100, 200, 255, 0.8)';
      ctx.fillText('AI CORE', cx, cy + R * 0.08);

      // Version
      ctx.font = `300 ${Math.max(8, R * 0.05)}px "JetBrains Mono", monospace`;
      ctx.fillStyle = 'rgba(140, 180, 200, 0.4)';
      ctx.fillText('v3.0.0', cx, cy + R * 0.16);

      // Status indicator
      const statusPulse = 0.5 + 0.5 * Math.sin(t * 0.05);
      ctx.beginPath();
      ctx.arc(cx + R * 0.25, cy + R * 0.12, 3, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(100, 220, 160, ${statusPulse})`;
      ctx.fill();

      rafRef.current = requestAnimationFrame(draw);
    }

    rafRef.current = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(rafRef.current);
      ro.disconnect();
    };
  }, []);

  return (
    <div className="w-full h-full flex items-center justify-center" style={{ backgroundColor: '#000000' }}>
      <canvas
        ref={canvasRef}
        style={{
          width: '100%',
          height: '100%',
          display: 'block',
        }}
      />
    </div>
  );
}
