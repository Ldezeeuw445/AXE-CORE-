import { useEffect, useState, useRef, useCallback } from 'react';
import { MapPin, Cloud, Wifi, MicOff, Command, Send, Circle } from 'lucide-react';
import { useUIStore } from '@/store/uiStore';
import { useVoiceStore } from '@/store/voiceStore';
import { VoiceWaveform } from '@/components/shared/VoiceWaveform';

export function BottomBar() {
  const { voiceState: uiVoiceState, setVoiceState, bottomBarVisible } = useUIStore();
  const voice = useVoiceStore();
  const [typedText, setTypedText] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (uiVoiceState !== voice.voiceStatus) setVoiceState(voice.voiceStatus);
  }, [voice.voiceStatus, uiVoiceState, setVoiceState]);

  if (!bottomBarVisible) return null;

  const isListening = voice.voiceStatus === 'listening';
  const isProcessing = voice.voiceStatus === 'processing';
  const isSpeaking = voice.voiceStatus === 'speaking';
  const isActive = isListening || isSpeaking || isProcessing;

  const handleVoiceClick = useCallback(async () => {
    try {
      if (!voice.apiKey) return;
      if (voice.voiceStatus === 'idle') await voice.startListening();
      else voice.stopListening();
    } catch (e: unknown) { console.error(e); }
  }, [voice.apiKey, voice.voiceStatus]);

  const handleSend = useCallback(async () => {
    try {
      if (!voice.apiKey || !typedText.trim()) return;
      const text = typedText.trim();
      setTypedText('');
      await voice.sendMessage(text);
    } catch (e: unknown) { console.error(e); }
  }, [voice.apiKey, typedText]);

  const label = isListening ? (voice.transcript || 'Listening...')
    : isProcessing ? 'AXE is thinking...'
    : isSpeaking ? (voice.response || 'Speaking...')
    : '';

  return (
    <footer className="fixed bottom-0 left-0 right-0 z-fixed flex items-center justify-between px-4" style={{ height: '64px', backgroundColor: '#000000', borderTop: '1px solid rgba(255,255,255,0.04)' }}>
      {/* Left — Location */}
      <div className="flex items-center gap-3 flex-shrink-0">
        <div className="flex items-center gap-1.5"><MapPin size={13} style={{ color: 'var(--text-muted)' }} /><span className="text-xs-custom" style={{ color: 'var(--text-secondary)' }}>Bhubaneswar, IN</span></div>
        <span style={{ color: 'var(--text-muted)' }}>·</span>
        <div className="flex items-center gap-1.5"><Cloud size={13} style={{ color: 'var(--text-muted)' }} /><span className="text-xs-custom" style={{ color: 'var(--text-secondary)' }}>28°C</span></div>
        <span style={{ color: 'var(--text-muted)' }}>·</span>
        <div className="flex items-center gap-1.5"><Wifi size={13} style={{ color: 'var(--success)' }} /><span className="text-xs-custom" style={{ color: 'var(--success)' }}>Excellent</span></div>
      </div>

      {/* Center — Composer Style Input */}
      <div className="flex items-center gap-2 flex-1 mx-6" style={{ maxWidth: '640px' }}>
        {/* Voice Record Button (composer style - circle) */}
        <button
          onClick={handleVoiceClick}
          className="flex-shrink-0 flex items-center justify-center rounded-full transition-all"
          style={{
            width: '36px',
            height: '36px',
            background: isListening ? 'rgba(34,211,238,0.15)' : '#0A0A0A',
            border: `1px solid ${isListening ? 'rgba(34,211,238,0.5)' : 'rgba(255,255,255,0.1)'}`,
          }}
          title={isListening ? 'Stop' : 'Talk to AXE'}
        >
          {isListening ? <MicOff size={16} style={{ color: 'var(--error)' }} /> : <Circle size={18} style={{ color: 'var(--text-secondary)' }} />}
        </button>

        {/* Input bar (composer style - white/light background) */}
        <div className="flex-1 flex items-center rounded-full overflow-hidden" style={{ backgroundColor: '#0A0A0A', border: '1px solid rgba(255,255,255,0.08)', height: '40px' }}>
          {isActive && label ? (
            <div className="flex-1 flex items-center px-4 gap-2 overflow-hidden">
              {isListening && <VoiceWaveform isActive={true} barCount={8} />}
              <span className="text-small truncate" style={{ color: isListening ? 'var(--accent-cyan)' : isProcessing ? 'var(--warning)' : 'var(--accent-blue)' }}>{label}</span>
              {isProcessing && <span className="flex gap-0.5 flex-shrink-0"><span className="animate-pulse" style={{ color: 'var(--accent-cyan)' }}>.</span><span className="animate-pulse" style={{ color: 'var(--accent-cyan)', animationDelay: '0.15s' }}>.</span><span className="animate-pulse" style={{ color: 'var(--accent-cyan)', animationDelay: '0.3s' }}>.</span></span>}
            </div>
          ) : (
            <input
              ref={inputRef}
              type="text"
              value={typedText}
              onChange={(e) => setTypedText(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleSend(); }}
              placeholder="Ask AXE anything..."
              className="flex-1 px-4 text-small outline-none bg-transparent"
              style={{ color: '#FFFFFF' }}
            />
          )}
        </div>

        {/* Send Button (composer style - cyan circle) */}
        <button
          onClick={handleSend}
          disabled={isActive || !typedText.trim()}
          className="flex-shrink-0 flex items-center justify-center rounded-full transition-all"
          style={{
            width: '36px',
            height: '36px',
            background: (!isActive && typedText.trim()) || isActive ? 'linear-gradient(135deg, #22D3EE, #06B6D4)' : '#0A0A0A',
            border: `1px solid ${(!isActive && typedText.trim()) || isActive ? 'rgba(34,211,238,0.5)' : 'rgba(255,255,255,0.1)'}`,
            opacity: (!isActive && typedText.trim()) || isActive ? 1 : 0.5,
            cursor: (!isActive && typedText.trim()) || isActive ? 'pointer' : 'default',
          }}
        >
          <Send size={16} style={{ color: (!isActive && typedText.trim()) || isActive ? '#000000' : 'var(--text-muted)' }} />
        </button>
      </div>

      {/* Right */}
      <div className="flex items-center gap-3 flex-shrink-0">
        {voice.apiKeyValid === true && <span className="text-xs-custom px-2 py-0.5 rounded" style={{ backgroundColor: 'rgba(16,185,129,0.1)', color: 'var(--success)' }}>API OK</span>}
        {voice.apiKeyValid === false && <span className="text-xs-custom px-2 py-0.5 rounded" style={{ backgroundColor: 'rgba(239,68,68,0.1)', color: 'var(--error)' }}>API Error</span>}
        <span className="text-xs-custom px-1.5 py-0.5 rounded" style={{ backgroundColor: '#1A1A1A', color: 'var(--text-muted)', fontFamily: 'JetBrains Mono, monospace' }}><Command size={10} className="inline mr-0.5" />K</span>
      </div>
    </footer>
  );
}
